package p2psaa.application.player;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;
import p2psaa.infrastructure.fileHandler.Song;

public class MP3Player {

	// ***********
	// Constructor
	// ***********

	private MP3Player() {
		// Not supposed to be called from outside
	}

	// ************
	// ATTRIBUTES
	// ************

	private static Player currentPlayer;
	private static Thread playThread;
	private static Song currentSong;

	// ****************
	// PUBLIC INTERFACE
	// ****************

	public static void play(final Song song) {

		if (song == null) {
			System.out.println("ERROR: song is null"); // TODO: remove debug output
			return;
		}

		currentSong = song;
		FileInputStream musicFileInputStream = null;

		try {
			File musicFile = new File(song.getFileName());
			musicFileInputStream = new FileInputStream(musicFile);
		}
		catch (IOException e2) {
			// TODO log instead of print stacktrace
			e2.printStackTrace();
		}

		if ((currentPlayer == null) || (currentPlayer.isComplete())) {
			try {
				currentPlayer = new Player(musicFileInputStream);
			}
			catch (JavaLayerException e1) {
				// TODO: log instead of printing stacktrace
				e1.printStackTrace();
			}

			Runnable myRunnable = new Runnable() {

				@Override
				public void run() {

					try {
						currentPlayer.play();

					}
					catch (JavaLayerException e) {
						// TODO: log instead of printing stacktrace
						e.printStackTrace();
					}
				}

			};

			playThread = new Thread(myRunnable);
			playThread.start();

		}
		else {
			// TODO: log instead of System.err writing
			System.err.println("There is already a song being played! Stop that first.");
		}

	}

	public static void stop() {

		if (currentPlayer == null) {

			// TODO: log instead of System.err writing
			System.err.println("There is no song playing that could be stopped.");
			return; // no player, so nothing to stop

		}
		else {
			currentSong.setSecondsPlayed(currentPlayer.getPosition() / 1000);

			System.out.println("Seconds played: " + currentSong.getSecondsPlayed());

			currentPlayer.close();
			currentPlayer = null;

			playThread.interrupt();
			playThread = null;

			currentSong = null;

		}

	}

	/*
	 * returns the time the song has been played till now (in s) or -1 if there is no song playingTODO: secondsPlayed if a song was played completely??
	 */
	public static int getSecondsPlayed() {

		if (currentPlayer != null) {

			return currentPlayer.getPosition() / 1000;

		}
		else {

			return -1;

		}
	}

	public static Song getCurrentSong() {
		return currentSong;
	}
}
