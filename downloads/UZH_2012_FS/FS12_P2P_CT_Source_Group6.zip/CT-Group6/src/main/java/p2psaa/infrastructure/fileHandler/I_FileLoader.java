package p2psaa.infrastructure.fileHandler;

import java.util.AbstractMap.SimpleEntry;
import java.util.List;

import net.tomp2p.peers.PeerAddress;

public interface I_FileLoader {

	public void deliverSongMetas(List<SimpleEntry<SongMeta, PeerAddress>> songMetas, List<String> processId);

	public void deliverSongs(List<Song> songs, List<String> processIds);

}
