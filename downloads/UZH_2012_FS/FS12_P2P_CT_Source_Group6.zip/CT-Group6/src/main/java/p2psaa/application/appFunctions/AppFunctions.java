package p2psaa.application.appFunctions;

import java.net.InetAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.application.player.MP3Player;
import p2psaa.domain.playlist.Playlist;
import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.p2p.DefaultP2P;
import p2psaa.infrastructure.p2p.I_P2P;
import p2psaa.ui.gui.MainWindow;

public class AppFunctions {

	// ***********
	// Attributes
	// ***********

	private static AppFunctions appFunctions = null;

	private Playlist playList = null;
	private MainWindow mainWin = null;
	private I_P2P defaultP2P = null;

	private static Logger logger = LoggerFactory.getLogger("AppFunctions");

	// ***********
	// Constructor
	// ***********

	private AppFunctions() {
		this.defaultP2P = DefaultP2P.getSingelton();
		this.playList = Playlist.getSingleton();

		logger.debug("Created.  {}", toString());
	}

	// ****************
	// Public interface
	// ****************

	public static AppFunctions getSingleton() {

		if (AppFunctions.appFunctions == null) {
			AppFunctions.appFunctions = new AppFunctions();
		}

		return AppFunctions.appFunctions;
	}

	public void startWithoutBootstrap() {
		try {

			this.defaultP2P.startWithoutBootstrap();

		}
		catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	/**
	 * 
	 */
	public Boolean connect(final InetAddress ip, final int port) {

		try {
			this.defaultP2P.connect(ip, port);
		}
		catch (Exception e) {
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @return
	 */
	public static Boolean disconnect() {
		return null;
	}

	/**
	 * 
	 */
	public Boolean nextSong(final String keyword, final boolean newList) {

		logger.debug("Ask for song for keyword '{}'", keyword);

		// stop if another song is being played
		MP3Player.stop();

		// get the next song on the playlist
		Song nextSong = this.playList.nextSong(keyword, newList);

		logger.debug("Got song '{}'", nextSong);

		if (nextSong != null) {
			// play the new song
			MP3Player.play(nextSong);
			return true;

		}
		else {
			logger.error("Didn't get a song for keyword '{}'", keyword);
			return false;
		}

	}

	public void setMainWindow(final MainWindow window) {
		this.mainWin = window;
	}

}
