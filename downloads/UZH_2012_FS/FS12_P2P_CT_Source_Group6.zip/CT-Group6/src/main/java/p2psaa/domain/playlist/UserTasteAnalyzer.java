package p2psaa.domain.playlist;

import java.util.Arrays;

import p2psaa.infrastructure.fileHandler.DefaultStorageAccess;
import p2psaa.infrastructure.fileHandler.I_StorageAccess;
import p2psaa.infrastructure.fileHandler.Song;

public class UserTasteAnalyzer {
	// if the song is played less than this threshold, we assume that the user dislikes it
	private static final int DONT_LIKE_THRESHOLD = 10;
	// if the song is played more than this threshold, we assume the user likes it
	private static final int LIKE_THRESHOLD = 20;

	public static void analyze(final Song song, final String globalKeyword, final String currentKeyword) {
		if ((song == null) || (globalKeyword == null) || (currentKeyword == null)) {
			return;
		}

		final I_StorageAccess sa = DefaultStorageAccess.getSingleton();

		if (song.getSecondsPlayed() <= DONT_LIKE_THRESHOLD) {
			sa.addDontLikeInformation(globalKeyword, Arrays.asList(song.getSongMeta().getTitle()));
		}
		else if (song.getSecondsPlayed() >= LIKE_THRESHOLD) {
			sa.addLikeInformation(globalKeyword, Arrays.asList(song.getSongMeta().getArtist(), song.getSongMeta().getTitle()));
		}
	}
}
