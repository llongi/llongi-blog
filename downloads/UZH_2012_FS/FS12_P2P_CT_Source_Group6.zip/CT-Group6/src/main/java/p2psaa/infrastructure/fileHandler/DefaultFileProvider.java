package p2psaa.infrastructure.fileHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.p2p.I_P2P;

public class DefaultFileProvider implements I_FileProvider {

	private static Logger logger = LoggerFactory.getLogger("DefaultFileProvider");

	private List<DefaultFileLoader> fileLoaders = new ArrayList<DefaultFileLoader>();

	private final Integer songNumber;
	private final long MAX_WAIT_TIME = 20000;

	private final I_StorageAccess storageAccess;
	private final I_P2P p2p;

	private HashMap<String, FileStack> keywordToFileStack = new HashMap<String, FileStack>();

	// ***********
	// Constructor
	// ***********

	public DefaultFileProvider(I_StorageAccess storageAccess, I_P2P p2p, Integer songNumber) {

		logger.debug("Created. ( {} , {} )", storageAccess, p2p);

		this.storageAccess = storageAccess;
		this.p2p = p2p;
		this.songNumber = songNumber;
	}

	// **************
	// Public methods
	// **************

	/*
	 * (non-Javadoc)
	 * 
	 * @see p2psaa.infrastructure.fileHandler.I_FileProvider#getSong(java.lang.String, p2psaa.infrastructure.fileHandler.I_Filter)
	 */
	public Song getSong(String keyword, I_Filter filter) {

		logger.debug("{} , {}", keyword, filter);
		
		keyword = DefaultFileHandler.normalizeKey(keyword);
		
		logger.info("Normalize keyword to : {}",keyword);

		FileStack fileStack = getFileStack(keyword);
		Song song = fileStack.getSong(filter);

		if (song == null || fileStack.needRefill()) {
			if (!existingFileLoader(fileStack, filter)) {
				DefaultFileLoader fileLoader = createAndExecuteFileLoader(fileStack, songNumber, filter);
				logger.debug("New FileLoader : {}", fileLoader);
			}
			logger.info("No matching song in filestack. Try to load new files from P2P");
		}

		if (song == null ) {

			if( (song = storageAccess.getRandomSong(keyword, filter)) == null ){
			
				logger.info("No matching song in local repository. Wait for P2P files ...");
				
				long startTime = System.currentTimeMillis();
				long currentTime = System.currentTimeMillis();
					
				while ((currentTime - startTime < MAX_WAIT_TIME)) {
					song = fileStack.getSong(filter);
					if (song != null) {
						break;
					}
					try {
						Thread.sleep(1000);
					}
					catch (InterruptedException e) {
					}
					currentTime = System.currentTimeMillis();
				}
				
				if( song == null ){
					logger.info("Din't got a song from P2P yet. Won't wait any longer");
				}
				
			} else {
				
			}

		}

		logger.debug("Got song {}", song);

		return song;

	}

	public String toString() {
		return this.getClass().getSimpleName() + "[" + this.storageAccess + "," + this.p2p + "]";
	}

	// ***************
	// Private methods
	// ***************

	private FileStack getFileStack(String keyword) {

		FileStack fileStack = this.keywordToFileStack.get(keyword);
		if (fileStack == null) {
			fileStack = new FileStack(keyword, 5);
			this.keywordToFileStack.put(keyword, fileStack);
		}

		return fileStack;
	}

	private DefaultFileLoader createAndExecuteFileLoader(FileStack fileStack, Integer maxSongs, I_Filter filter) {
		DefaultFileLoader fl = new DefaultFileLoader(fileStack, filter, maxSongs, this.p2p);
		this.fileLoaders.add(fl);
		fl.start();
		return fl;
	}

	private boolean existingFileLoader(FileStack fileStack, I_Filter filter) {
		for (DefaultFileLoader fl : this.fileLoaders) {
			if (fl.equalConfig(fileStack, filter)) {
				if (fl.isAlive()) {
					return true;
				}
				else {
					this.fileLoaders.remove(fl);
					return false;
				}
			}
		}

		return false;
	}

}
