package p2psaa.ui.gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import p2psaa.application.appFunctions.AppFunctions;
import p2psaa.settings.Configuration;

@SuppressWarnings("serial")
public class BootstrapWindow extends JFrame {

	private JPanel contentPane;
	private JTextField IPadressTextField;
	private JTextField portTextField;
	private JButton joinButton;

	/**
	 * Create the frame.
	 */
	public BootstrapWindow() {

		// set up the window
		setBackground(Color.WHITE);
		setForeground(Color.DARK_GRAY);
		setTitle("Welcome ");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 477, 293);

		// set up the content pane of the window
		this.contentPane = new JPanel();
		this.contentPane.setBackground(Color.BLACK);
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		// create Label that writes the instruction to the user
		JLabel lblEnterTheIpv = new JLabel("Enter the address of the bootstrap node:");
		lblEnterTheIpv.setBounds(15, 12, 432, 15);
		lblEnterTheIpv.setForeground(Color.WHITE);
		lblEnterTheIpv.setBackground(Color.BLACK);
		this.contentPane.add(lblEnterTheIpv);

		// create textfield for entering the ip-address
		this.IPadressTextField = new JTextField();
		this.IPadressTextField.setBounds(224, 39, 164, 34);
		this.IPadressTextField.setColumns(10);
		this.contentPane.add(this.IPadressTextField);

		// IP4 label
		JLabel IPcaptionLabel = new JLabel("Bootstrap IPv4:");
		IPcaptionLabel.setBounds(89, 48, 128, 15);
		IPcaptionLabel.setForeground(Color.WHITE);
		IPcaptionLabel.setBackground(Color.BLACK);
		this.contentPane.add(IPcaptionLabel);

		// Join button
		this.joinButton = new JButton("");
		this.joinButton.setIcon(new ImageIcon("resources/images/joinButton.png"));
		this.joinButton.setPressedIcon(new ImageIcon("resources/images/joinButtonPressed.png"));
		this.joinButton.setBorderPainted(false);
		this.joinButton.setContentAreaFilled(false);
		this.joinButton.setBounds(196, 146, 80, 80);
		this.contentPane.add(this.joinButton);

		JLabel portLabel = new JLabel("Bootstrap Port:");
		portLabel.setBounds(89, 109, 128, 15);
		portLabel.setForeground(Color.WHITE);
		portLabel.setBackground(Color.BLACK);
		this.contentPane.add(portLabel);

		this.portTextField = new JTextField();
		this.portTextField.setBounds(224, 100, 164, 34);
		this.portTextField.setColumns(10);
		this.portTextField.setText(Configuration.localP2PPort.toString());
		this.contentPane.add(this.portTextField);

		this.joinButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(final ActionEvent evt) {
				setVisible(false);
				MainWindow mainWin = new MainWindow();

				AppFunctions appFunctions = AppFunctions.getSingleton();
				appFunctions.setMainWindow(mainWin);

				String ipStr = BootstrapWindow.this.IPadressTextField.getText();

				if (ipStr.equals("")) {
					appFunctions.startWithoutBootstrap();
				}
				else {
					InetAddress ip = null;

					try {
						ip = InetAddress.getByName(ipStr);
					}
					catch (UnknownHostException e) {
						System.out.println("ERROR: Unknown Host: " + ipStr);
					}

					Integer port = Integer.valueOf(BootstrapWindow.this.portTextField.getText());

					appFunctions.connect(ip, port);
				}

				dispose();
			}
		});

		// position the window in the middle of the screen
		setLocationRelativeTo(null);
		setVisible(true);
	}

	public JButton getJoinButton() {
		return this.joinButton;
	}
}
