package p2psaa.application.player;

public interface I_PlayerObserver {

	public void callbackStop();

	public void callbackDone();

	public void callbackStart();

	public void callbackPause();

}
