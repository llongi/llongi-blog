package p2psaa.infrastructure.p2p;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import net.tomp2p.futures.FutureBootstrap;
import net.tomp2p.futures.FutureData;
import net.tomp2p.futures.FutureDiscover;
import net.tomp2p.futures.FutureTracker;
import net.tomp2p.p2p.Peer;
import net.tomp2p.p2p.PeerMaker;
import net.tomp2p.p2p.config.ConfigurationTrackerStore;
import net.tomp2p.p2p.config.Configurations;
import net.tomp2p.peers.Number160;
import net.tomp2p.peers.PeerAddress;
import net.tomp2p.rpc.ObjectDataReply;
import net.tomp2p.storage.TrackerData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.fileHandler.AlwaysTrueFilter;
import p2psaa.infrastructure.fileHandler.DefaultFileHandler;
import p2psaa.infrastructure.fileHandler.DefaultFileLoader;
import p2psaa.infrastructure.fileHandler.I_NewFileListener;
import p2psaa.infrastructure.fileHandler.I_StorageAccess;
import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.fileHandler.SongMeta;

public class DefaultP2PAccess implements I_P2PAccess, I_NewFileListener {

	private static Logger logger = LoggerFactory.getLogger("DefaultDHT");

	private net.tomp2p.p2p.Peer localTomP2PPeer;

	private final Integer localPort;

	private final Map<Number160, Integer> localContent = new HashMap<Number160, Integer>();

	private final I_StorageAccess storageAccess;

	public DefaultP2PAccess(final Integer localPort, final I_StorageAccess storageAccess) {
		this.localPort = localPort;
		this.storageAccess = storageAccess;
	} 

	@Override
	public void put(String key) throws IOException {

		key = DefaultFileHandler.normalizeKey(key);

		logger.debug("Gonna announce that i have data for the key '{}'", key);

		Number160 n160Key = Number160.createHash(key);
		Integer count = this.localContent.get(n160Key);
		if (count == null) {
			count = 1;
		}
		else {
			count++;
		}
		this.localContent.put(n160Key, count);

		logger.info("I have {} files matching the key '{}' now", count, key);

		announce();
	}

	@Override
	public List<PeerAddress> getPeers(String key) {

		key = DefaultFileHandler.normalizeKey(key);

		logger.debug("Ask DHT for peers with data for the key '{}'", key);

		Number160 nb160key = Number160.createHash(key);

		Collection<TrackerData> trackerDatas = queryTracker(nb160key);

		List<PeerAddress> peerAddresses = new ArrayList<PeerAddress>();
		for (TrackerData td : trackerDatas) {
			peerAddresses.add(td.getPeerAddress());
		}

		return peerAddresses;
	}

	@Override
	public Song loadSong(final PeerAddress peerAddress, final SongMeta songMeta) {

		logger.info("Ask peer '{}' for song '{}' ", peerAddress, songMeta);

		try {

			P2PRequest p2pRequest = new P2PRequest(P2PRequest.RequestType.SONG, songMeta);

			FutureData futureData = send(peerAddress, p2pRequest);
			futureData.awaitUninterruptibly();

			if (futureData.isSuccess()) {
				byte[] content = (byte[]) futureData.getObject();
				Song song = this.storageAccess.addSongFromP2P(songMeta, content);

				return song;
			}
			else {
				return null;
			}

		}
		catch (Exception e) {
			return null;
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<SongMeta> loadAllSongMeta(final PeerAddress peerAddress, String keyword, final Integer maxNbr) {
		logger.info("Ask peer '{}' for songmetas for keyword '{}' ", peerAddress, keyword);

		keyword = DefaultFileHandler.normalizeKey(keyword);

		logger.debug("Ask peer '{}' for songmetas for keyword '{}' ", peerAddress,keyword);
		

		try {

			P2PRequest p2pRequest = new P2PRequest(P2PRequest.RequestType.SONGMETA, new String[] { keyword, maxNbr.toString() });

			FutureData futureData = send(peerAddress, p2pRequest);
			futureData.awaitUninterruptibly();

			if (futureData.isSuccess() && (futureData.getObject() instanceof List<?>)) {
				return (List<SongMeta>) futureData.getObject();
			}
			else {
				return new ArrayList<SongMeta>();
			}

		}
		catch (Exception e) {
			return null;
		}

	}

	@Override
	public void startWithoutBootstrap() throws Exception {

		this.localTomP2PPeer = new PeerMaker(Number160.createHash(System.nanoTime())).setPorts(this.localPort).buildAndListen();

		logger.debug("Set ReplyHandler for {}", this.localTomP2PPeer);

		setReplyHandler(this.localTomP2PPeer);

		this.storageAccess.registerNewLocalFileListener(this);
		
		logger.info("Local peer started");
	}

	@Override
	public void bootstrap(final InetAddress ipTarget, final Integer portTarget) throws Exception {

		logger.debug("Try to bootstrap to {} on port {}", ipTarget, portTarget);

		startWithoutBootstrap();

		// Bootstraping

		try {

			// FIXME: NAT PROBLEMS TO SOLVE
			InetSocketAddress inetSock = new InetSocketAddress(ipTarget, portTarget);
			FutureDiscover fd = this.localTomP2PPeer.discover(ipTarget, portTarget, portTarget);

			fd.awaitUninterruptibly(1000);

			boolean success = fd.isSuccess();

			logger.debug("Bootstrap successfull : {}", success);

			FutureBootstrap fb = this.localTomP2PPeer.bootstrap(inetSock);
			fb.awaitUninterruptibly(1000);

			logger.info("Local peer connected to P2P network");
			
		}
		catch (Exception e) {
			logger.info("Bootstraping didn't work. ({})", e.getMessage());
			
		}

	}

	@Override
	public void disconnect() {
		this.localTomP2PPeer.shutdown();
	}

	@Override
	public void newLocalFile(Song song) {
		logger.debug("Got information that a new local file has been added: {}",song);
		try{
			put(song.getSongMeta().getArtist());
			put(song.getSongMeta().getGenre());
			put(song.getSongMeta().getTitle());
		}
		catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	// ***************
	// Private methods
	// ***************

	private Collection<TrackerData> queryTracker(final Number160 key) {

		FutureTracker futureTracker = this.localTomP2PPeer.getFromTracker(key, Configurations.defaultTrackerGetConfiguration());
		// now we know which peer has this data, and we also know what other things this peer has
		futureTracker.awaitUninterruptibly();
		Collection<TrackerData> trackerDatas = futureTracker.getTrackers();
		return trackerDatas;
	}

	private FutureData send(final PeerAddress address, final P2PRequest p2pRequest) throws IOException {
		return this.localTomP2PPeer.send(address, p2pRequest);
	}

	private void announce() throws IOException {
		logger.debug("Gonna announce my current local content");

		for (Number160 key : this.localContent.keySet()) {
			ConfigurationTrackerStore cts = Configurations.defaultTrackerStoreConfiguration();
			this.localTomP2PPeer.addToTracker(key, cts).awaitUninterruptibly();
		}
	}

	private void setReplyHandler(final Peer peer) {
		peer.setObjectDataReply(new ObjectDataReply() {

			@Override
			public Object reply(final PeerAddress sender, final Object request) throws Exception {
				logger.info("Got a request from the DHT (Peer {}) : '{}'", sender, request);

				if (request != null) {

					if (request instanceof P2PRequest) {

						P2PRequest p2pRequest = (P2PRequest) request;

						switch (p2pRequest.getRequestType()) {
							case SONG:
								if (p2pRequest.getRequestPayload() instanceof SongMeta) {
									SongMeta songMeta = (SongMeta) p2pRequest.getRequestPayload();
									Song song = DefaultP2PAccess.this.storageAccess.getSongByMetaInfo(songMeta);

									byte[] content = song.getFileContent();

									logger.debug("Return : {}",song);

									return content;
								}
								else {
									logger.debug("Return: null");

									return null;
								}
							case SONGMETA:
								if (p2pRequest.getRequestPayload() instanceof String[]) {
									String[] requestParams = (String[]) p2pRequest.getRequestPayload();
									String keyword = requestParams[0];
									Integer maxNbr = Integer.valueOf(requestParams[1]);
									List<SongMeta> songMetas = loadSongMetas(keyword, maxNbr);

									logger.debug("Return: {}",Arrays.toString(songMetas.toArray()));

									return songMetas;
								}
								else {

									logger.debug("Return: null");

									return null;
								}
						}

					}
				}

				logger.debug("Request was invalid");

				return null;
			}
		});
	}

	private List<SongMeta> loadSongMetas(final String keyword, final Integer maxNbr) {

		Random random = new Random(System.currentTimeMillis());

		List<SongMeta> songMetas = new ArrayList<SongMeta>();
		// FIXME: Should be replaced by a better selection algorithm. I just want to get it running now.
		List<Song> songs = this.storageAccess.getAllSongs(keyword, AlwaysTrueFilter.getSingelton());
		int count = 0;
		while ((count < maxNbr) && (songs.size() > 0)) {
			int selected = random.nextInt(songs.size());
			songMetas.add(songs.get(selected).getSongMeta());
			songs.remove(selected);
			count++;
		}

		return songMetas;
	}

}
