package p2psaa.ui.gui;

import java.awt.Color;

import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;

import p2psaa.infrastructure.logging.I_LoggerObserver;
import p2psaa.infrastructure.logging.ObservableLogbackAppender;
import ch.qos.logback.classic.spi.ILoggingEvent;

/*
 * Create a simple console to display text messages.
 * 
 * Messages can be directed here from different sources. Each source can have its messages displayed in a different color.
 * 
 * Messages can either be appended to the console or inserted as the first line of the console
 * 
 * You can limit the number of lines to hold in the Document.
 */
public class MessageConsole implements I_LoggerObserver {
	private JTextArea textOutput;

	public MessageConsole() {
		// Create an area to show informative text
		this.textOutput = new JTextArea();
		this.textOutput.setBackground(Color.BLACK);
		this.textOutput.setForeground(Color.WHITE);
		this.textOutput.setEditable(false);
		this.textOutput.setLineWrap(true);

		// Always scroll down on new text
		final DefaultCaret caret = (DefaultCaret) this.textOutput.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

		// Register so we receive messages
		ObservableLogbackAppender.register(this);
	}

	public JTextArea getTextOutput() {
		return (this.textOutput);
	}

	@Override
	public void receiveLogEvent(final ILoggingEvent logEvent) {
		this.textOutput.append(logEvent.getFormattedMessage() + "\n");
	}
}
