package p2psaa.infrastructure.logging;

import ch.qos.logback.classic.spi.ILoggingEvent;

public interface I_LoggerObserver {

	public void receiveLogEvent(ILoggingEvent event);
	
	
}
