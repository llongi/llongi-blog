package p2psaa.infrastructure.fileHandler;

public interface I_FileHandler {

	public abstract Song getSong(String keyword, I_Filter filter);

}
