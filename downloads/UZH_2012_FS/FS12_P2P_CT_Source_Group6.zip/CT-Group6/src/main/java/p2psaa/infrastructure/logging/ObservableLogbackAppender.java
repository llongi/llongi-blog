package p2psaa.infrastructure.logging;

import java.util.ArrayList;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.ConsoleAppender;
import ch.qos.logback.core.LogbackException;

public class ObservableLogbackAppender extends ConsoleAppender<ILoggingEvent>{

	  private static ArrayList<I_LoggerObserver> loggerObserver = new ArrayList<I_LoggerObserver>();
	   
	  public static void register(I_LoggerObserver observer){
		  synchronized (loggerObserver) {
			 loggerObserver.add(observer);
		  }
	  }
	
	  public void doAppend(ILoggingEvent event) throws LogbackException {
		  
		 synchronized (loggerObserver) {
			 for(I_LoggerObserver o : loggerObserver){
				 o.receiveLogEvent(event);
			 }
		 }			  
		  
		  
		  super.doAppend(event);
	  }
}
