package p2psaa.infrastructure.fileHandler;


import java.util.HashSet;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileStack {

	private static Logger logger = LoggerFactory.getLogger("FileStack");

	private final String keyword;
	private final Integer minSize;

	private Set<Song> songSet = new HashSet<Song>();

	// ***********
	// Constructor
	// ***********

	public FileStack(String keyword, Integer minSize) {
		this.keyword = keyword;
		this.minSize = minSize;
		
		logger.debug("Created. {}",this.toString());
	}

	// **************
	// Public methods
	// **************

	public String toString() {
		return this.getClass().getSimpleName() + "[" + this.keyword + "," + this.minSize + "," + this.songSet.size() + "]";
	}

	public boolean needRefill() {
		return (this.songSet.size() < this.minSize);
	}

	public String getKeyword() {
		return this.keyword;
	}

	public Song getSong(I_Filter filter) {
		Song result = null;
		synchronized (this.songSet) {
			for (Song s : this.songSet) {
				if (filter.verify(s.getSongMeta())) {
					result = s;
					break;
				}
			}
			if (result != null) {
				this.songSet.remove(result);
			}
		}

		return result;
	}

	public boolean addSong(Song song) {
		logger.debug(song.toString());
		synchronized (this.songSet) {
			if (this.songSet.contains(song)) {
				return false;
			}
			this.songSet.add(song);
			return true;
		}
	}

}
