package p2psaa.infrastructure.p2p;

import java.net.InetAddress;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import net.tomp2p.peers.PeerAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.fileHandler.DefaultStorageAccess;
import p2psaa.infrastructure.fileHandler.I_FileLoader;
import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.fileHandler.SongMeta;
import p2psaa.settings.Configuration;

public class DefaultP2P implements I_P2P {

	private static Logger logger = LoggerFactory.getLogger("DefaultP2P");

	private static I_P2P p2p = null;

	private I_P2PAccess dht;

	private HashMap<String, WorkerThread> idToWorkerThread = new HashMap<String, WorkerThread>();

	// ***********
	// Constructor
	// ***********

	protected DefaultP2P(final I_P2PAccess dht) {
		this.dht = dht;
	}

	// **************
	// Public static
	// **************

	public static I_P2P getSingelton() {
		if (DefaultP2P.p2p == null) {
			Integer localPort = Configuration.localP2PPort;
			DefaultP2P.p2p = new DefaultP2P(new DefaultP2PAccess(localPort, DefaultStorageAccess.getSingleton()));
		}
		return DefaultP2P.p2p;
	}

	// ****************
	// Public Interface
	// ****************

	@Override
	public void startWithoutBootstrap() throws Exception {
		this.dht.startWithoutBootstrap();
	}

	@Override
	public void connect(final InetAddress ip, final Integer port) throws Exception {
		if ((ip == null) || (port == null)) {
			this.dht.startWithoutBootstrap();
		}
		else {
			this.dht.bootstrap(ip, port);
		}
	}

	@Override
	public void disconnect() throws Exception {
		this.dht.disconnect();
	}

	@Override
	public String getSongMetas(final String keyword, final int number, final I_FileLoader loaderThread) {

		// Generate unique thread id
		String id = String.valueOf(System.nanoTime());

		// Start new thread for requesting DHT and loading SongMeta from Peers
		WorkerThread workerThread = new SongMetasWorkerThread(id, keyword, loaderThread, this, number);
		this.idToWorkerThread.put(id, workerThread);
		workerThread.start();

		return id;
	}

	@Override
	public String loadSong(final SongMeta songMeta, final PeerAddress peerAddress, final I_FileLoader fileLoader) {

		// Generate unique thread id
		String id = String.valueOf(System.nanoTime());

		// Start new thread for requesting DHT and loading SongMeta from Peers
		WorkerThread workerThread = new SongWorkerThread(id, songMeta, peerAddress, fileLoader, this);
		this.idToWorkerThread.put(id, workerThread);
		workerThread.start();

		return id;
	}

	@Override
	public boolean isProcessAlive(final String processId) {

		if (this.idToWorkerThread.containsKey(processId)) {
			if (this.idToWorkerThread.get(processId) != null) {
				if (this.idToWorkerThread.get(processId).isAlive()) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName();
	}

	// ***************
	// Private methods
	// ***************

	private void workerThreadDone(final WorkerThread workerThread) {

		if (workerThread instanceof SongMetasWorkerThread) {
			SongMetasWorkerThread smwt = (SongMetasWorkerThread) workerThread;
			this.idToWorkerThread.remove(smwt.getThreadId());
			workerThread.getFileLoader().deliverSongMetas(smwt.getResults(), Arrays.asList(new String[] { smwt.getThreadId() }));
			return;
		}

		if (workerThread instanceof SongWorkerThread) {
			SongWorkerThread swt = (SongWorkerThread) workerThread;
			this.idToWorkerThread.remove(swt.getThreadId());
			workerThread.getFileLoader().deliverSongs(Arrays.asList(new Song[] { swt.getResult() }), Arrays.asList(new String[] { swt.getThreadId() }));
			return;
		}

	}

	// *************
	// Private class
	// *************

	private abstract class WorkerThread extends Thread {
		private final String id;
		private final I_FileLoader fileLoader;
		private final DefaultP2P parent;

		public WorkerThread(final String id, final I_FileLoader fileLoader, final DefaultP2P parent) {
			this.id = id;
			this.fileLoader = fileLoader;
			this.parent = parent;
		}

		public String getThreadId() {
			return this.id;
		}

		public I_FileLoader getFileLoader() {
			return this.fileLoader;
		}
	}

	private class SongMetasWorkerThread extends WorkerThread {

		private final Integer number;
		private final String keyword;

		private ArrayList<SimpleEntry<SongMeta, PeerAddress>> results = new ArrayList<SimpleEntry<SongMeta, PeerAddress>>();

		public SongMetasWorkerThread(final String id, final String keyword, final I_FileLoader fileLoader, final DefaultP2P parent, final Integer number) {
			super(id, fileLoader, parent);
			this.number = number;
			this.keyword = keyword;
		}

		public ArrayList<SimpleEntry<SongMeta, PeerAddress>> getResults() {
			return this.results;
		}

		@Override
		public void run() {

			List<PeerAddress> peersForKeyword = super.parent.dht.getPeers(this.keyword);

			if (peersForKeyword.size() == 0) {
				logger.debug("There is no peer with data for the given keyword '{}'", this.keyword);
				return;
			}

			Random random = new Random(System.currentTimeMillis());

			// Select random peer; Try to get "number" of SongMetas; Try other peers if not enough SongMetas received
			Integer nbrLeft = this.number;
			boolean done = false;

			while (!done) {
				int peerNbr = random.nextInt(peersForKeyword.size());
				PeerAddress peerAddress = peersForKeyword.get(peerNbr);
				peersForKeyword.remove(peerNbr);

				try {
					List<SongMeta> songMetas = super.parent.dht.loadAllSongMeta(peerAddress, this.keyword, nbrLeft);
					nbrLeft = nbrLeft - songMetas.size();
					for (SongMeta sm : songMetas) {
						this.results.add(new SimpleEntry<SongMeta, PeerAddress>(sm, peerAddress));
					}
				}
				catch (Exception e) {
					logger.error(e.getMessage());
				}

				logger.debug("Got {} SongMetas {} left to get", this.results.size(), nbrLeft);

				if ((nbrLeft <= 0) || (peersForKeyword.size() == 0)) {
					done = true;
					if ((nbrLeft > 0) && (peersForKeyword.size() == 0)) {
						logger.debug("Didn't get enough songs but there are no peers left to ask...");
					}
				}
			}

			logger.debug("Done.");

			// FIXME: Have to see if this scales -> will start some cascading method calls. Could be implemented better. Good enough for testing the process.
			super.parent.workerThreadDone(this);

		}

	}

	private class SongWorkerThread extends WorkerThread {

		private final SongMeta songMeta;
		private final PeerAddress peerAddress;

		private Song result;

		public SongWorkerThread(final String id, final SongMeta songMeta, final PeerAddress peerAddress, final I_FileLoader fileLoader,
			final DefaultP2P parent) {
			super(id, fileLoader, parent);
			this.songMeta = songMeta;
			this.peerAddress = peerAddress;
		}

		@Override
		public void run() {

			try {
				this.result = super.parent.dht.loadSong(this.peerAddress, this.songMeta);
			}
			catch (Exception e) {
				logger.error(e.getMessage());
			}

			super.parent.workerThreadDone(this);

		}

		public Song getResult() {
			return this.result;
		}
	}

}
