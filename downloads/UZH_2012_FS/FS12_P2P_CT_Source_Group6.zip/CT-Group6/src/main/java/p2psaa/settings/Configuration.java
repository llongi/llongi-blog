package p2psaa.settings;

public class Configuration {
	public static final Integer localP2PPort = 5000;
	public static final Integer stackSize    = 5;
	public static final String p2pAppPathMain = System.getProperty("user.home") + "/p2pradio/";
	public static final String p2pAppPathDownload = p2pAppPathMain + "dl/";
	public static final String p2pAppPathData = p2pAppPathMain + "data/";
}
