package p2psaa.domain.playlist;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.fileHandler.BlacklistFilter;
import p2psaa.infrastructure.fileHandler.DefaultFileHandler;
import p2psaa.infrastructure.fileHandler.DefaultStorageAccess;
import p2psaa.infrastructure.fileHandler.I_FileHandler;
import p2psaa.infrastructure.fileHandler.I_Filter;
import p2psaa.infrastructure.fileHandler.I_StorageAccess;
import p2psaa.infrastructure.fileHandler.Song;

public class Playlist {

	private static Logger logger = LoggerFactory.getLogger("Playlist");

	private static Playlist playlist = null;

	private I_StorageAccess storageAccess;
	private I_FileHandler fileHandler;
	private String currentKeyword = null;
	private Song prevSong = null;

	// ***********
	// Constructor
	// ***********

	private Playlist() {
		this.fileHandler = DefaultFileHandler.getSingleton();
		this.storageAccess = DefaultStorageAccess.getSingleton();
		logger.debug("Created.  {}", toString());
	}

	// ****************
	// Public interface
	// ****************

	public static Playlist getSingleton() {

		if (Playlist.playlist == null) {
			Playlist.playlist = new Playlist();
		}

		return Playlist.playlist;

	}

	public Song nextSong(final String keyword, final boolean newList) {

		if (newList) {
			this.currentKeyword = null;
			this.prevSong = null;
		}

		if ((this.prevSong != null) && (this.currentKeyword != null)) {
			UserTasteAnalyzer.analyze(this.prevSong, keyword, this.currentKeyword);
		}

		if (this.currentKeyword != null) {

			long choose = System.nanoTime() % 3;

			String newKeyword = null;

			if (choose == 0) {
				newKeyword = this.storageAccess.getRandomKeywordLike(this.currentKeyword, keyword);
			}

			if ((choose == 1) || (newKeyword == null)) {
				// Found nothing new, fall back to global keyword!
				if (this.prevSong != null) {
					newKeyword = this.prevSong.getSongMeta().getGenre();
				}
			}

			if ((choose == 3) || (newKeyword == null)) {
				newKeyword = keyword;
			}

			this.currentKeyword = newKeyword;
		}
		else {
			this.currentKeyword = keyword;
		}

		logger.info("Working keyword: {}", this.currentKeyword);

		List<String> dontLike = this.storageAccess.getAllKeywordsDontLike(this.currentKeyword, keyword);
		I_Filter filter = new BlacklistFilter(dontLike);

		Song nextSong = this.fileHandler.getSong(this.currentKeyword, filter);

		if ((nextSong == null) && (this.prevSong != null)) {
			// Try again with the genre if nothing found to be sure
			nextSong = this.fileHandler.getSong(this.prevSong.getSongMeta().getGenre(), filter);
		}

		this.prevSong = nextSong;

		logger.info("Got song: {}", nextSong);

		return nextSong;
	}
}
