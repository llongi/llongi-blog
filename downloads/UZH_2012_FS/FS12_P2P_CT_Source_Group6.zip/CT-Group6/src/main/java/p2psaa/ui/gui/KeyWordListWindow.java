package p2psaa.ui.gui;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import p2psaa.infrastructure.fileHandler.DefaultStorageAccess;
import p2psaa.infrastructure.fileHandler.I_StorageAccess;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JSeparator;


public class KeyWordListWindow extends JFrame {
	
	private JPanel likePanel= new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dontlikePanel = new JPanel();
	private I_StorageAccess storage = DefaultStorageAccess.getSingleton();
	private String likeWord, globalWord;
	
	
	public KeyWordListWindow(String likeKeyWord, String globalKeyWord) {
		getContentPane().setLayout(new GridLayout(1, 3, 0, 0));
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.likeWord = likeKeyWord;
		this.globalWord = globalKeyWord;
		
		createLeftPanel();
		createMiddlePanel();
		createRightPanel();
		
		this.getContentPane().add(this.likePanel);
		this.getContentPane().add(this.middlePanel);
		this.getContentPane().add(this.dontlikePanel);
		this.setLocationRelativeTo(null);
		this.pack();
		this.setVisible(true);
	}
	
	private void createLeftPanel(){
		
		likePanel.setLayout(new GridLayout(20, 1));
		
		List<String> likeWords = storage.getAllKeywordsLike(likeWord, globalWord);
		
		if(likeWords.size() < 1){
			for(int i=0; i< 20; i++){
				likePanel.add(new JLabel("no keyword"));
			}
			return;
		}
		
		
		for(String s: likeWords){
			likePanel.add(new JLabel(s));
		}
		
	}
	
	private void createMiddlePanel(){
		
		middlePanel.setLayout(new GridLayout(20,1));
		
		for(int i=0; i < 20; i++){
			middlePanel.add(new JLabel("  --  "));
		}
		
	}
	
	
	private void createRightPanel(){
		
		dontlikePanel.setLayout(new GridLayout(20,1));
		
		List<String> dontlikeWords = storage.getAllKeywordsDontLike(likeWord, globalWord);
		
		if(dontlikeWords.size() < 1){
			for(int i=0; i< 20; i++){
				dontlikePanel.add(new JLabel("no keyword"));
			}
			return;
		}
		
		for(String s: dontlikeWords){
			dontlikePanel.add(new JLabel(s));
		}
		
	}

}
