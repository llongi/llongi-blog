package p2psaa.infrastructure.fileHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Song implements Serializable {
	private static final long serialVersionUID = 3470564234071762744L;
	private final SongMeta songMeta;
	private final String fileName;
	private int secondsPlayed;

	private static Logger logger = LoggerFactory.getLogger("Song");

	// ***********
	// Constructor
	// ***********

	public Song(final String fileName, final SongMeta songMeta) {
		this.fileName = fileName;
		this.songMeta = songMeta;
	}

	// **************
	// Public methods
	// **************

	public SongMeta getSongMeta() {
		return this.songMeta;
	}

	public String getFileName() {
		return this.fileName;
	}

	public byte[] getFileContent() {
		return readFile(new File(this.fileName));
	}

	public void setSecondsPlayed(final int seconds) {
		this.secondsPlayed = seconds;
	}

	public int getSecondsPlayed() {
		return this.secondsPlayed;
	}

	@Override
	public String toString() {
		return "Song [songMeta=" + this.songMeta + ", fileName=" + this.fileName + ", secondsPlayed=" + this.secondsPlayed + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((this.songMeta == null) ? 0 : this.songMeta.hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Song other = (Song) obj;
		if (this.songMeta == null) {
			if (other.songMeta != null) {
				return false;
			}
		}
		else if (!this.songMeta.equals(other.songMeta)) {
			return false;
		}
		return true;
	}

	private byte[] readFile(final File f) {
		FileInputStream fileInStream = null;
		final byte[] fileContent = new byte[(int) f.length()];

		try {
			fileInStream = new FileInputStream(f);
			final int read = fileInStream.read(fileContent);
			if (read != fileContent.length) {
				throw new IOException();
			}
		}
		catch (final FileNotFoundException e) {
			logger.debug("File not found: " + f.getAbsolutePath());
		}
		catch (final IOException e) {
			logger.debug("IO Exception: " + e.toString() + " on reading from file at " + f.getAbsolutePath());
		}
		finally {
			if (fileInStream != null) {
				try {
					fileInStream.close();
				}
				catch (final IOException e) {
					// Just ignore this!
				}
			}
		}

		return fileContent;
	}
}
