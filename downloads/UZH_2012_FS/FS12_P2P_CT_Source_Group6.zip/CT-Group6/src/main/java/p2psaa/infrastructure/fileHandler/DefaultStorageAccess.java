package p2psaa.infrastructure.fileHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.audio.exceptions.CannotReadException;
import org.jaudiotagger.audio.exceptions.InvalidAudioFrameException;
import org.jaudiotagger.audio.exceptions.ReadOnlyFileException;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.TagException;
import org.jaudiotagger.tag.reference.GenreTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.settings.Configuration;

public class DefaultStorageAccess implements I_StorageAccess {

	private Set<Song> songsSet; // Set of songs, so we have no duplicates!
	private Map<String, Set<String>> likeKeywordsMap; // Keyword -> List of Like Keywords
	private Map<String, Set<String>> dontLikeKeywordsMap; // Keyword -> List of Don't Like Keywords

	private final List<I_NewFileListener> newFileListeners = new ArrayList<I_NewFileListener>();

	// **************
	// Private static
	// **************

	private static Logger logger = LoggerFactory.getLogger("DefaultStorageAccess");
	private static I_StorageAccess storageAccess;

	protected String pathSongsSet;
	protected String pathLikeKeywordsMap;
	protected String pathDontLikeKeywordsMap;
	protected String p2pAppPathDownload;
	protected String p2pAppPathData;
	protected String p2pAppPathMain;

	// *************
	// Public static
	// *************

	public synchronized static I_StorageAccess getSingleton() {
		if (DefaultStorageAccess.storageAccess == null) {
			DefaultStorageAccess.storageAccess = new DefaultStorageAccess();
		}

		return DefaultStorageAccess.storageAccess;
	}

	// ***********
	// Constructor
	// ***********

	protected DefaultStorageAccess() {

		this.p2pAppPathMain = Configuration.p2pAppPathMain;
		this.p2pAppPathData = Configuration.p2pAppPathData;

		this.pathSongsSet = Configuration.p2pAppPathData + "songsSet.save";
		this.pathLikeKeywordsMap = Configuration.p2pAppPathData + "likeKeywordsMap.save";
		this.pathDontLikeKeywordsMap = Configuration.p2pAppPathData + "dontLikeKeywordsMap.save";

		this.p2pAppPathDownload = Configuration.p2pAppPathDownload;

		// No public constructor is supposed to exist

		initDirs();

		initMaps();

		logger.debug("Created.  {}", toString());
	}

	@SuppressWarnings("unchecked")
	protected void initMaps() {

		// Read data from file, null if nothing to read, in that case initialize manually to empty.
		this.songsSet = (Set<Song>) readIn(this.pathSongsSet);
		if (this.songsSet == null) {
			this.songsSet = new HashSet<Song>();
		}

		this.likeKeywordsMap = (Map<String, Set<String>>) readIn(this.pathLikeKeywordsMap);
		if (this.likeKeywordsMap == null) {
			this.likeKeywordsMap = new HashMap<String, Set<String>>();
		}

		this.dontLikeKeywordsMap = (Map<String, Set<String>>) readIn(this.pathDontLikeKeywordsMap);
		if (this.dontLikeKeywordsMap == null) {
			this.dontLikeKeywordsMap = new HashMap<String, Set<String>>();
		}

	}

	protected void initDirs() {
		final File basePath = new File(this.p2pAppPathMain);
		if (!basePath.exists()) {
			if (basePath.mkdir()) {
				logger.debug("{} created ", basePath.getAbsoluteFile());
			}
			else {
				logger.error("error while creating {}", basePath.getAbsoluteFile());
			}
		}

		final File dataPath = new File(this.p2pAppPathData);
		if (!dataPath.exists()) {
			if (dataPath.mkdir()) {
				logger.debug("{} created ", dataPath.getAbsoluteFile());
			}
			else {
				logger.error("error while creating {}", dataPath.getAbsoluteFile());
			}
		}

		final File baseDownload = new File(this.p2pAppPathDownload);
		if (!baseDownload.exists()) {
			if (baseDownload.mkdir()) {
				logger.debug("{} created ", baseDownload.getAbsoluteFile());
			}
			else {
				logger.error("error while creating {}", baseDownload.getAbsoluteFile());
			}
		}
	}

	// **************
	// Public methods
	// **************

	@Override
	public Song getSongByMetaInfo(final SongMeta metaInfo) {
		synchronized (this.songsSet) {
			for (final Song s : this.songsSet) {
				if (s.getSongMeta().equals(metaInfo)) {
					return s;
				}
			}
		}

		return null;
	}

	@Override
	public Song getRandomSong(final String keyword, final I_Filter filter) {
		final List<Song> allSongs = getAllSongs(keyword, filter);

		// We have no songs to return!
		if (allSongs.isEmpty()) {
			return null;
		}

		final Random rand = new Random();
		final int randNr = rand.nextInt(allSongs.size());

		return allSongs.get(randNr);
	}

	@Override
	public List<Song> getAllSongs() {
		final List<Song> allSongs = new ArrayList<Song>();

		synchronized (this.songsSet) {
			for (final Song s : this.songsSet) {
				allSongs.add(s);
			}
		}

		return allSongs;
	}

	@Override
	public List<Song> getAllSongs(String keyword, final I_Filter filter) {
		keyword = DefaultFileHandler.normalizeKey(keyword);
		final List<Song> allSongsFiltered = new ArrayList<Song>();

		synchronized (this.songsSet) {
			for (final Song s : this.songsSet) {
				String artist = DefaultFileHandler.normalizeKey(s.getSongMeta().getArtist());
				String title = DefaultFileHandler.normalizeKey(s.getSongMeta().getTitle());
				String genre = DefaultFileHandler.normalizeKey(s.getSongMeta().getGenre());

				if (keyword.equals(artist) || keyword.equals(title) || keyword.equals(genre)) {
					if (filter.verify(s.getSongMeta())) {
						allSongsFiltered.add(s);
					}
				}
			}
		}

		return allSongsFiltered;
	}

	

	@Override
	public Song addSongFromFile(final String filePath) {
		// Get the meta-information from the song's tags
		final SongMeta metaInfo = analyzeSong(filePath);

		// Check that we don't already have this song locally, if we do, we don't add it twice
		synchronized (this.songsSet) {
			for (final Song s : this.songsSet) {
				if (s.getSongMeta().equals(metaInfo)) {
					return s;
				}
			}
		}

		final Song song = new Song(filePath, metaInfo);

		synchronized (this.songsSet) {
			this.songsSet.add(song);

			writeOut(this.songsSet, this.pathSongsSet);
		}

		synchronized (this.newFileListeners) {
			for (final I_NewFileListener i : this.newFileListeners) {
				i.newLocalFile(song);
			}
		}

		return song;
	}

	@Override
	public Song addSongFromP2P(final SongMeta metaInfo, final byte[] content) {
		// Check that we don't already have this song locally, if we do, we don't add it twice
		synchronized (this.songsSet) {
			for (final Song s : this.songsSet) {
				if (s.getSongMeta().equals(metaInfo)) {
					return s;
				}
			}
		}

		// Path for new song: user dir as a base
		final String songFilePath = this.p2pAppPathDownload + metaInfo.toFileName("mp3");
		final File songFile = new File(songFilePath);

		// Create file if not already there
		try {
			songFile.createNewFile();
		}
		catch (final IOException e) {
			logger.debug("IO Exception: " + e.toString() + " on file creation at " + songFile.getAbsolutePath());
		}

		FileOutputStream fileOutStream = null;

		try {
			fileOutStream = new FileOutputStream(songFile);
			fileOutStream.write(content);
		}
		catch (final FileNotFoundException e) {
			logger.debug("File not found: " + songFile.getAbsolutePath());
		}
		catch (final IOException e) {
			logger.debug("IO Exception: " + e.toString() + " on writing to file at " + songFile.getAbsolutePath());
		}
		finally {
			if (fileOutStream != null) {
				try {
					fileOutStream.close();
				}
				catch (final IOException e) {
					// Just ignore this!
				}
			}
		}

		final Song song = new Song(songFilePath, metaInfo);

		synchronized (this.songsSet) {
			this.songsSet.add(song);

			writeOut(this.songsSet, this.pathSongsSet);
		}

		synchronized (this.newFileListeners) {
			for (final I_NewFileListener i : this.newFileListeners) {
				i.newLocalFile(song);
			}
		}

		return song;
	}

	/**
	 * 
	 */
	@Override
	public void registerNewLocalFileListener(final I_NewFileListener listener) {

		logger.debug("gonna register new listener: {}", listener);

		synchronized (this.newFileListeners) {
			this.newFileListeners.add(listener);
			for (final Song s : getAllSongs()) {
				listener.newLocalFile(s);
			}
		}

	}

	// *******
	// PRIVATE
	// *******

	private SongMeta analyzeSong(final String songFilePath) {
		AudioFile f = null;
		try {
			f = AudioFileIO.read(new File(songFilePath));
		}
		catch (final CannotReadException e) {
			logger.debug("Cannot read audio file: " + songFilePath);
		}
		catch (final IOException e) {
			logger.debug("IO Exception: " + e.toString() + " on tag analysis at " + songFilePath);
		}
		catch (final TagException e) {
			logger.debug("Tag Exception on tag analysis at " + songFilePath);
		}
		catch (final ReadOnlyFileException e) {
			logger.debug("File is read only: " + songFilePath);
		}
		catch (final InvalidAudioFrameException e) {
			logger.debug("Invalid audio file: " + songFilePath);
		}

		final Tag tag = f.getTag();

		final String artist = tag.getFirst(FieldKey.ARTIST);
		final String title = tag.getFirst(FieldKey.TITLE);
		String genre = tag.getFirst(FieldKey.GENRE);

		// Fix broken tags
		if (genre.charAt(0) == '(') {
			final int idx = genre.indexOf(')');

			if (idx >= 2) {
				// We have a number in parentheses, isolate it
				genre = genre.substring(1, idx);
			}
		}

		try {
			genre = GenreTypes.getInstanceOf().getValueForId(Integer.valueOf(genre));
		}
		catch (final NumberFormatException e) {
			// Ignore exception
		}

		logger.debug("genre is " + genre);

		return new SongMeta(artist, title, genre);
	}

	@Override
	public void addLikeInformation(final String keyword, final List<String> likeKeywords) {
		final String keywordLower = keyword.toLowerCase();

		synchronized (this.likeKeywordsMap) {
			if (!this.likeKeywordsMap.containsKey(keywordLower)) {
				this.likeKeywordsMap.put(keywordLower, new HashSet<String>());
			}

			for (final String s : likeKeywords) {
				this.likeKeywordsMap.get(keywordLower).add(s.toLowerCase());
			}

			writeOut(this.likeKeywordsMap, this.pathLikeKeywordsMap);
		}
	}

	@Override
	public void addDontLikeInformation(final String keyword, final List<String> dontLikeKeywords) {
		final String keywordLower = keyword.toLowerCase();

		synchronized (this.dontLikeKeywordsMap) {
			if (!this.dontLikeKeywordsMap.containsKey(keywordLower)) {
				this.dontLikeKeywordsMap.put(keywordLower, new HashSet<String>());
			}

			for (final String s : dontLikeKeywords) {
				this.dontLikeKeywordsMap.get(keywordLower).add(s.toLowerCase());
			}

			writeOut(this.dontLikeKeywordsMap, this.pathDontLikeKeywordsMap);
		}
	}

	@Override
	public String getRandomKeywordLike(final String likeKeyword, final String globalKeyword) {
		final List<String> allKeywords = getAllKeywordsLike(likeKeyword, globalKeyword);

		// We have no keywords to return!
		if (allKeywords.isEmpty()) {
			return null;
		}

		final Random rand = new Random();
		final int randNr = rand.nextInt(allKeywords.size());

		return allKeywords.get(randNr);
	}

	@Override
	public List<String> getAllKeywordsLike(final String likeKeyword, final String globalKeyword) {
		final String likeKeywordLower = likeKeyword.toLowerCase();
		final String globalKeywordLower = globalKeyword.toLowerCase();

		// Calculate similar keywords to what we passed in
		final List<String> similarKeywords = new ArrayList<String>();

		synchronized (this.likeKeywordsMap) {
			final Set<String> likes = this.likeKeywordsMap.get(likeKeywordLower);
			final Set<String> globalLikes = this.likeKeywordsMap.get(globalKeywordLower);

			// Get the like information
			if (likes != null) {
				for (final String s : likes) {
					similarKeywords.add(s);
				}
			}
			else {
				// We have no like information for the current keyword, let's fall back to the global one!
				if (globalLikes != null) {
					for (final String s : globalLikes) {
						similarKeywords.add(s);
					}
				}
			}
		}

		// If nothing was found, for both keywords, it makes no sense to remove the disliked keywords, since there is
		// nothing at all, so just return an empty list.
		if (similarKeywords.isEmpty()) {
			return similarKeywords;
		}

		synchronized (this.dontLikeKeywordsMap) {
			final Set<String> dislikes = this.dontLikeKeywordsMap.get(likeKeywordLower);
			final Set<String> globalDislikes = this.dontLikeKeywordsMap.get(globalKeywordLower);

			// Some likes were found, so let's make sure to remove the dislikes from them, both current and global!
			if (dislikes != null) {
				for (final String s : dislikes) {
					similarKeywords.remove(s);
				}
			}

			if ((globalDislikes != null) && (globalDislikes != dislikes)) {
				for (final String s : globalDislikes) {
					similarKeywords.remove(s);
				}
			}
		}

		// Now return the cleaned up list, this might be empty, if everything was disliked!
		return similarKeywords;
	}

	@Override
	public List<String> getAllKeywordsDontLike(final String dontLikeKeyword, final String globalKeyword) {
		final String dontLikeKeywordLower = dontLikeKeyword.toLowerCase();
		final String globalKeywordLower = globalKeyword.toLowerCase();

		// Get all don't like keywords for the passed keywords
		final List<String> dontLikeKeywords = new ArrayList<String>();

		synchronized (this.dontLikeKeywordsMap) {
			final Set<String> dislikes = this.dontLikeKeywordsMap.get(dontLikeKeywordLower);
			final Set<String> globalDislikes = this.dontLikeKeywordsMap.get(globalKeywordLower);

			// Some dislikes were found, add them
			if (dislikes != null) {
				for (final String s : dislikes) {
					dontLikeKeywords.add(s);
				}
			}

			if ((globalDislikes != null) && (globalDislikes != dislikes)) {
				for (final String s : globalDislikes) {
					dontLikeKeywords.add(s);
				}
			}
		}

		return dontLikeKeywords;
	}

	private void writeOut(final Object obj, final String path) {
		final File f = new File(path);

		// Create file if not already there
		try {
			f.createNewFile();
		}
		catch (final IOException e) {
			logger.debug("IO Exception: " + e.toString() + " on file creation at " + f.getAbsolutePath());
		}

		// Write object to file
		try {
			final FileOutputStream fos = new FileOutputStream(f);
			final ObjectOutputStream oos = new ObjectOutputStream(fos);

			oos.writeObject(obj);

			oos.close();
			fos.close();
		}
		catch (final IOException e) {
			logger.debug("IO Exception: " + e.toString() + " on object write at " + f.getAbsolutePath());
		}
	}

	private Object readIn(final String path) {
		final File f = new File(path);

		// Check that file actually exists
		if (!f.exists()) {
			return null;
		}

		// Read object from file
		Object obj = null;

		try {
			final FileInputStream fis = new FileInputStream(f);
			final ObjectInputStream ois = new ObjectInputStream(fis);

			obj = ois.readObject();

			ois.close();
			fis.close();
		}
		catch (final IOException e) {
			logger.debug("IO Exception: " + e.toString() + " on object read at " + f.getAbsolutePath());
		}
		catch (final ClassNotFoundException e) {
			// Impossible exception, Object always exists!
		}

		return obj;
	}
}
