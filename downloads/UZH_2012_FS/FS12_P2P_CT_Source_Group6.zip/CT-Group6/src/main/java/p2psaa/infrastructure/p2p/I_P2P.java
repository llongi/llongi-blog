package p2psaa.infrastructure.p2p;

import java.net.InetAddress;

import net.tomp2p.peers.PeerAddress;

import p2psaa.infrastructure.fileHandler.I_FileLoader;
import p2psaa.infrastructure.fileHandler.SongMeta;

public interface I_P2P {

	/**
	 * 
	 * if ip and/or port are null -> start without bootstraping
	 * 
	 */
	public abstract void connect(InetAddress ip, Integer port) throws Exception;

	/*
	 * 
	 */
	public abstract void disconnect() throws Exception;

	/**
	 * 
	 * This method is supposed to start a new thread for loading files and return afterwards. The loaded files are supposed to be delivered by means of the
	 * given callback interface.
	 * 
	 * @param keyword
	 * @param number
	 * @param loaderThread
	 * @return Process id
	 */
	public abstract String getSongMetas(String keyword, int number, I_FileLoader loaderThread);

	/**
	 * 
	 * This method is supposed to start a new thread for loading files and return afterwards. The loaded files are supposed to be delivered by means of the
	 * given callback interface.
	 * 
	 * 
	 * @param songMetas
	 * @param loaderThread
	 * @return Process id
	 */
	public abstract String loadSong(SongMeta songMeta, PeerAddress peerAddress, I_FileLoader fileLoader);

	public boolean isProcessAlive(String processId);
	
	public void startWithoutBootstrap() throws Exception;

}
