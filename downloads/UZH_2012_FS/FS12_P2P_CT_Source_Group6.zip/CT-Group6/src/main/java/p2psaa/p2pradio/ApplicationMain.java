package p2psaa.p2pradio;

import java.awt.EventQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.ui.gui.BootstrapWindow;

/**
 * Hello world!
 * 
 */
public class ApplicationMain {
	// **********
	// ATTRIBUTES
	// **********

	public static Logger logger = LoggerFactory.getLogger("ApplicationMain");

	// *************
	// PUBLIC STATIC
	// *************

	public static void main(String[] args) {
		// construct playlist

		// show the GUI
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BootstrapWindow frame = new BootstrapWindow();
					frame.setVisible(true);
				}
				catch (Exception e) {
					logger.error(e.getMessage());
				}
			}
		});
	}
}
