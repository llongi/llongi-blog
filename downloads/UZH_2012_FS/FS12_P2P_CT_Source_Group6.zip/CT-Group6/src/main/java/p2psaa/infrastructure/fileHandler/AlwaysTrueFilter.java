package p2psaa.infrastructure.fileHandler;

/**
 * 
 * Always returns true.
 * 
 * @author robert
 * 
 */
public class AlwaysTrueFilter implements I_Filter {

	private static AlwaysTrueFilter alwaysTrueFilter = null;

	private AlwaysTrueFilter() {

	}

	/**
	 * Always returns true.
	 */
	public boolean verify(final SongMeta songMeta) {
		return true;
	}

	/**
	 * 
	 * @return
	 */
	public static AlwaysTrueFilter getSingelton() {
		if (AlwaysTrueFilter.alwaysTrueFilter == null) {
			AlwaysTrueFilter.alwaysTrueFilter = new AlwaysTrueFilter();
		}
		return AlwaysTrueFilter.alwaysTrueFilter;
	}

}
