package p2psaa.infrastructure.fileHandler;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

public class SongMeta implements Serializable {
	private static final long serialVersionUID = 2021680528565750556L;
	private final String artist;
	private final String title;
	private final String genre;

	// ***********
	// Constructor
	// ***********

	public SongMeta(final String artist, final String title, final String genre) {
		this.artist = artist;
		this.title = title;
		this.genre = genre;
	}

	// ******
	// Getter
	// ******

	public String getArtist() {
		return this.artist;
	}

	public String getTitle() {
		return this.title;
	}

	public String getGenre() {
		return this.genre;
	}

	// **************
	// Public methods
	// **************
	@Override
	public String toString() {
		return "SongMeta [artist=" + this.artist + ", title=" + this.title + ", genre=" + this.genre + "]";
	}

	public String toFileName(final String suffix) {
		return "song-" + this.artist + "-" + this.title + "-" + this.genre + "." + suffix;
	}

	public String toCsv() {
		final String csv = this.genre + ";" + this.artist + ";" + this.title;
		return csv;
	}

	// *********************
	// Public static methods
	// *********************

	public static SongMeta fromCsv(final String csv) {
		final String[] splitted = StringUtils.splitPreserveAllTokens(csv, ";");
		final String genre = splitted[0];
		final String artist = splitted[1];
		final String title = splitted[2];

		final SongMeta songMeta = new SongMeta(artist, title, genre);

		return songMeta;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((this.artist == null) ? 0 : this.artist.toLowerCase().hashCode());
		result = (prime * result) + ((this.genre == null) ? 0 : this.genre.toLowerCase().hashCode());
		result = (prime * result) + ((this.title == null) ? 0 : this.title.toLowerCase().hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final SongMeta other = (SongMeta) obj;

		if (this.artist == null) {
			if (other.artist != null) {
				return false;
			}
		}
		else if (!this.artist.equalsIgnoreCase(other.artist)) {
			return false;
		}

		if (this.genre == null) {
			if (other.genre != null) {
				return false;
			}
		}
		else if (!this.genre.equalsIgnoreCase(other.genre)) {
			return false;
		}

		if (this.title == null) {
			if (other.title != null) {
				return false;
			}
		}
		else if (!this.title.equalsIgnoreCase(other.title)) {
			return false;
		}

		return true;
	}
}
