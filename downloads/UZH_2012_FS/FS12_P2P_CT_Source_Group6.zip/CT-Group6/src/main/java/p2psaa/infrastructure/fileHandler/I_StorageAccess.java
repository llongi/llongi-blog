package p2psaa.infrastructure.fileHandler;

import java.util.List;

public interface I_StorageAccess {
	public abstract Song getSongByMetaInfo(SongMeta metaInfo);

	public abstract Song getRandomSong(String keyword, I_Filter filter);

	public abstract List<Song> getAllSongs();

	public abstract List<Song> getAllSongs(String keyword, I_Filter filter);

	public abstract Song addSongFromFile(String filePath);

	public abstract Song addSongFromP2P(SongMeta metaInfo, byte[] content);

	public abstract void addLikeInformation(String keyword, List<String> likeKeywords);

	public abstract void addDontLikeInformation(String keyword, List<String> dontLikeKeywords);

	public abstract String getRandomKeywordLike(String likeKeyword, String globalKeyword);

	public abstract List<String> getAllKeywordsLike(String likeKeyword, String globalKeyword);

	public abstract List<String> getAllKeywordsDontLike(String dontLikeKeyword, String globalKeyword);

	public abstract void registerNewLocalFileListener(I_NewFileListener listener);
}
