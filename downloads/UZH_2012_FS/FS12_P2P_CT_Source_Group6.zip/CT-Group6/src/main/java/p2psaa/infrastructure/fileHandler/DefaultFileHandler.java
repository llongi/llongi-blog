package p2psaa.infrastructure.fileHandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.p2p.DefaultP2P;
import p2psaa.settings.Configuration;

/**
 * Public interface of FileHandler module. Communication with this module is supposed to happen only by means of this class.
 * 
 * @author robert
 * 
 */
public class DefaultFileHandler implements I_FileHandler {

	// **********
	// Attributes
	// **********
	
	private static Logger logger = LoggerFactory.getLogger("DefaultFileHandler");

	private static I_FileHandler fileHandler = null;

	private I_StorageAccess storageAccess = null;
	private I_FileProvider fileProvider = null;

	// ***********
	// Constructor
	// ***********

	private DefaultFileHandler() {
		this.storageAccess = DefaultStorageAccess.getSingleton();
		this.fileProvider = new DefaultFileProvider(this.storageAccess, DefaultP2P.getSingelton(), Configuration.stackSize);
		logger.debug("Created.  {}",this.toString());
	}

	// *************
	// PUBLIC STATIC
	// *************

	public static I_FileHandler getSingleton() {
		if (DefaultFileHandler.fileHandler == null) {
			DefaultFileHandler.fileHandler = new DefaultFileHandler();
		}
		return DefaultFileHandler.fileHandler;
	}

	// ****************
	// PUBLIC INTERFACE
	// ****************
	
	public static String normalizeKey(String key){
		
		key = key.toLowerCase();
		key = key.replaceAll(" ", "");
		
		return key;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see p2psaa.infrastructure.fileHandler.I_FileHandler#getSong(java.lang.String, p2psaa.infrastructure.fileHandler.I_Filter)
	 */
	@Override
	public Song getSong(final String keyword, final I_Filter filter) {
		return this.fileProvider.getSong(keyword, filter);
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + "[" + this.storageAccess + "," + this.fileProvider + "]";
	}

}
