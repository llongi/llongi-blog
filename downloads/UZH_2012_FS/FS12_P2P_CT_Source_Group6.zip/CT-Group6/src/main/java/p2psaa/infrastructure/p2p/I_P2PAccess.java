package p2psaa.infrastructure.p2p;

import java.io.IOException;
import java.net.InetAddress;
import java.util.List;

import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.fileHandler.SongMeta;

import net.tomp2p.peers.PeerAddress;

public interface I_P2PAccess {

	/**
	 * Value is always "<IP>:<PORT>:<PEERNAME>" since put is only used by a single peer to announce that he has data
	 * 
	 * @param key
	 */
	public void put(String key) throws IOException;

	public List<PeerAddress> getPeers(String key);

	public List<SongMeta> loadAllSongMeta(PeerAddress peerAddress, String keyword, Integer maxNbr);

	public Song loadSong(PeerAddress peerAddress, SongMeta songMeta);

	public void bootstrap(InetAddress ipTarget, Integer portTarget) throws Exception;

	public void disconnect() throws Exception;

	public void startWithoutBootstrap() throws Exception;
}
