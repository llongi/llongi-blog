package p2psaa.ui.gui;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import p2psaa.application.appFunctions.AppFunctions;
import p2psaa.application.player.MP3Player;
import p2psaa.infrastructure.fileHandler.DefaultStorageAccess;
import p2psaa.infrastructure.fileHandler.I_StorageAccess;

@SuppressWarnings("serial")
public class MainWindow extends JFrame {

	private JPanel contentPane;
	private MessageConsole mc;
	private JFileChooser fc;
	private String keyWord;
	private JTextField keyWordTextField;
	private Font titleFont = new Font("Comic Sans MS", Font.BOLD, 18);
	private Font subTitleFont = new Font("Ubuntu", Font.BOLD, 15);
	private Font clockFont = new Font("Courier", Font.BOLD, 20);
	private JLabel currentSongLabel = new JLabel("------");
	private JLabel currentArtistLabel = new JLabel("------");
	private JLabel currentGenreLabel = new JLabel("------");
	
	//clock
	private Clock clock = new Clock();
	private boolean clocking = false;
	private JLabel clockLabel;
	private Thread clockThread;

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		
		setTitle("P2P Online Radio: Main Menu");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 750);
		
		this.contentPane = new BackGroundPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(this.contentPane);
		this.contentPane.setLayout(null);

		JSeparator verticalSeperator = new JSeparator();
		verticalSeperator.setOrientation(SwingConstants.VERTICAL);
		verticalSeperator.setForeground(Color.BLACK);
		verticalSeperator.setBackground(Color.BLACK);
		verticalSeperator.setBounds(556, -12, 35, 431);
		this.contentPane.add(verticalSeperator);

		JSeparator upperHorizontalSeperator = new JSeparator();
		upperHorizontalSeperator.setBackground(Color.BLACK);
		upperHorizontalSeperator.setForeground(Color.BLACK);
		upperHorizontalSeperator.setBounds(0, 33, 898, 18);
		this.contentPane.add(upperHorizontalSeperator);

		JLabel playListLabel = new JLabel("Create & play automated Playlist:");
		playListLabel.setFont(titleFont);
		playListLabel.setForeground(Color.WHITE);
		playListLabel.setBounds(12, 12, 306, 15);
		this.contentPane.add(playListLabel);

		JLabel lblShareYourOwn = new JLabel("Share your own songs to others:");
		lblShareYourOwn.setFont(titleFont);
		lblShareYourOwn.setForeground(Color.WHITE);
		lblShareYourOwn.setBounds(572, 14, 285, 15);
		this.contentPane.add(lblShareYourOwn);

		JSeparator lowerHorizontalSeperator = new JSeparator();
		lowerHorizontalSeperator.setBackground(Color.BLACK);
		lowerHorizontalSeperator.setForeground(Color.BLACK);
		lowerHorizontalSeperator.setBounds(-14, 418, 912, 18);
		this.contentPane.add(lowerHorizontalSeperator);

		JLabel fileChooseLabel = new JLabel("Choose the song you want to add:");
		fileChooseLabel.setFont(subTitleFont);
		fileChooseLabel.setForeground(Color.WHITE);
		fileChooseLabel.setBounds(572, 43, 326, 34);
		this.contentPane.add(fileChooseLabel);

		// FileChooser
		JButton fileChooseButton = new JButton("");
		fileChooseButton.setIcon(new ImageIcon("resources/images/shareButton1.png"));
		fileChooseButton.setPressedIcon(new ImageIcon("resources/images/shareButtonPressed.png"));
		fileChooseButton.setContentAreaFilled(false);
		fileChooseButton.setBorderPainted(false);
		fileChooseButton.setBounds(685, 80, 50, 50);
		fileChooseButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(final ActionEvent e) {
				I_StorageAccess sa = DefaultStorageAccess.getSingleton();

				MainWindow.this.fc = new JFileChooser();
				MainWindow.this.fc.setMultiSelectionEnabled(true);
				MainWindow.this.fc.showOpenDialog((JFrame) null);
				File[] fileArr = MainWindow.this.fc.getSelectedFiles();

				for (File element : fileArr) {
					sa.addSongFromFile(element.getPath());
				}
			}
		});
		this.contentPane.add(fileChooseButton);

		JLabel keywordLabel = new JLabel("Enter keyword:");
		keywordLabel.setFont(subTitleFont);
		keywordLabel.setBounds(26, 63, 319, 27);
		keywordLabel.setForeground(Color.WHITE);
		this.contentPane.add(keywordLabel);

		this.keyWordTextField = new JTextField();
		this.keyWordTextField.setBounds(26, 97, 167, 19);
		this.contentPane.add(this.keyWordTextField);
		this.keyWordTextField.setColumns(10);
		
		JLabel currentSongTitleLabel = new JLabel("Current Song:");
		currentSongTitleLabel.setFont(titleFont);
		currentSongTitleLabel.setForeground(Color.WHITE);
		currentSongTitleLabel.setBackground(Color.BLACK);
		currentSongTitleLabel.setBounds(26, 150, 300, 20);
		this.contentPane.add(currentSongTitleLabel);
		
		
		currentSongLabel.setFont(subTitleFont);
		currentSongLabel.setForeground(Color.WHITE);
		currentSongLabel.setBackground(Color.BLACK);
		currentSongLabel.setBounds(26, 200, 500, 20);
		this.contentPane.add(currentSongLabel);
		
		
		currentArtistLabel.setFont(subTitleFont);
		currentArtistLabel.setForeground(Color.WHITE);
		currentArtistLabel.setBackground(Color.BLACK);
		currentArtistLabel.setBounds(26, 250, 500, 20);
		this.contentPane.add(currentArtistLabel);
		
		currentGenreLabel.setFont(subTitleFont);
		currentGenreLabel.setForeground(Color.WHITE);
		currentGenreLabel.setBackground(Color.BLACK);
		currentGenreLabel.setBounds(26, 300, 500, 20);
		this.contentPane.add(currentGenreLabel);
		
		

		// PLAY button
		JButton playButton = new JButton("");
		playButton.setIcon(new ImageIcon("resources/images/playButton.png"));
		playButton.setPressedIcon(new ImageIcon("resources/images/playButtonPressed.png"));
		playButton.setContentAreaFilled(false);
		playButton.setBorderPainted(false);
		playButton.setBounds(374, 82, 60, 60);
		playButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(final ActionEvent e) {

				MainWindow.this.keyWord = MainWindow.this.keyWordTextField.getText();

				AppFunctions appFunctions = AppFunctions.getSingleton();
				Boolean success = appFunctions.nextSong(MainWindow.this.keyWordTextField.getText(),true);

				if (!success) {
					JOptionPane.showMessageDialog(MainWindow.this, "Didn't get a song for keyword " + MainWindow.this.keyWord);
				}else{
					startClock();
					
					String songTitle = MP3Player.getCurrentSong().getSongMeta().getTitle();
					String songArtist = MP3Player.getCurrentSong().getSongMeta().getArtist();
					String songGenre = MP3Player.getCurrentSong().getSongMeta().getGenre();
					
					currentSongLabel.setText(songTitle);
					currentArtistLabel.setText(songArtist);
					currentGenreLabel.setText(songGenre);
				}
				

			}
		});
		this.contentPane.add(playButton);

		// NEXTSONG Button
		JButton forwardButton = new JButton("");
		forwardButton.setBounds(479, 182, 60, 60);
		
		forwardButton.setIcon(new ImageIcon("resources/images/nextButton.png"));
		forwardButton.setPressedIcon(new ImageIcon("resources/images/nextButtonPressed.png"));
		forwardButton.setContentAreaFilled(false);
		forwardButton.setBorderPainted(false);
		forwardButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(final ActionEvent e) {

				Boolean success = AppFunctions.getSingleton().nextSong(MainWindow.this.keyWordTextField.getText(),false);

				if (!success) {
					stopClock();
					clockLabel.setText("");
					currentSongLabel.setText("-------");
					currentArtistLabel.setText("-------");
					currentGenreLabel.setText("-------");
					JOptionPane.showMessageDialog(MainWindow.this, "Didn't get a song for keyword " + MainWindow.this.keyWord);
					
				}else{
					stopClock();
					clockLabel.setText("");
					startClock();
					String songTitle = MP3Player.getCurrentSong().getSongMeta().getTitle();
					String songArtist = MP3Player.getCurrentSong().getSongMeta().getArtist();
					String songGenre = MP3Player.getCurrentSong().getSongMeta().getGenre();
					
					currentSongLabel.setText(songTitle);
					currentArtistLabel.setText(songArtist);
					currentGenreLabel.setText(songGenre);
				}
			}
		});
		this.contentPane.add(forwardButton);

		// STOP button
		JButton stopButton = new JButton("");
		stopButton.setBounds(266, 182, 60, 60);
		stopButton.setIcon(new ImageIcon("resources/images/stopButton.png"));
		stopButton.setPressedIcon(new ImageIcon("resources/images/stopButtonPressed.png"));
		stopButton.setContentAreaFilled(false);
		stopButton.setBorderPainted(false);
		stopButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(final ActionEvent e) {
				MP3Player.stop();
				stopClock();
				clockLabel.setText("");
				currentSongLabel.setText("----------");
				currentArtistLabel.setText("----------");
				currentGenreLabel.setText("----------");
				
				
			}
		});
		this.contentPane.add(stopButton);

		
		clockLabel = new JLabel("Time");
		clockLabel.setBounds(380, 132, 100, 100); 
		clockLabel.setForeground(Color.WHITE);
		clockLabel.setBackground(Color.BLACK);
		clockLabel.setFont(clockFont);
		this.contentPane.add(clockLabel);
		
		
		this.mc = new MessageConsole();
		JScrollPane scrollPane = new JScrollPane(this.mc.getTextOutput());
		scrollPane.setBounds(32, 463, 819, 209);
		this.contentPane.add(scrollPane);

		JLabel lblIoConsoleOutput = new JLabel("IO Console Output:");
		lblIoConsoleOutput.setFont(titleFont);
		lblIoConsoleOutput.setBounds(36, 432, 208, 18);
		lblIoConsoleOutput.setForeground(Color.WHITE);
		this.contentPane.add(lblIoConsoleOutput);

		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBackground(Color.BLACK);
		separator.setBounds(556, 152, 341, 18);
		this.contentPane.add(separator);
		
		JLabel metaInfoLabel = new JLabel("Meta-Infos:");
		metaInfoLabel.setFont(titleFont);
		metaInfoLabel.setBackground(Color.BLACK);
		metaInfoLabel.setForeground(Color.WHITE);
		metaInfoLabel.setBounds(572, 150, 300, 46);
		this.contentPane.add(metaInfoLabel);


		
		JButton showKeyWordsButton = new JButton("Show Like keywords");
		showKeyWordsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				new KeyWordListWindow(MainWindow.this.keyWordTextField.getText(), MainWindow.this.keyWordTextField.getText());
				
			}
		});
		showKeyWordsButton.setBounds(623, 265, 185, 51);
		contentPane.add(showKeyWordsButton);

		setLocationRelativeTo(null); // center the window
		setVisible(true);

	}

	public String getUsersKeyWord() {
		return this.keyWord;
	}
	
	public void startClock(){
		this.clocking = true;
		Runnable clockRunnable = new Runnable() {
			
			@Override
			public void run() {
				while(MainWindow.this.clocking){
					clockLabel.setText(clock.getTimeString());
				}
				
			}
		};
		
		clock.start();
		clockThread = new Thread(clockRunnable);
		clockThread.start();
	}
	
	public void stopClock(){
		if(clockThread != null){
			try {
				clockThread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			clockThread.interrupt();
			MainWindow.this.clocking = false;
			
			clockThread = null;
		}
		clock.stopAndReset();
		
	}
	
	public class BackGroundPanel extends JPanel {
		
		private ImageIcon backgroundImage;
		
		public BackGroundPanel() {
			// TODO Auto-generated constructor stub
			this.backgroundImage = new ImageIcon("resources/images/background6.jpg");
		}
		
		
		public void paintComponent(Graphics g){
			g.drawImage(backgroundImage.getImage(), 0, 0, null);
			
		}
		
	}
}
