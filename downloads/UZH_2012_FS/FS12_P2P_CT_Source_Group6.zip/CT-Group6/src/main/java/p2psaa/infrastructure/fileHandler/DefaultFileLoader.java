package p2psaa.infrastructure.fileHandler;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.AbstractMap.SimpleEntry;

import net.tomp2p.peers.PeerAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.p2p.I_P2P;

public class DefaultFileLoader extends Thread implements I_FileLoader {

	private final FileStack fileStack;
	private final I_Filter filter;
	private final int maxSongs;
	private final I_P2P p2p;

	private static Logger logger = LoggerFactory.getLogger("DefaultFileLoader");
	private static final long MAX_WAIT_TIME = 600000L; // 10 Minuten

	private Set<SimpleEntry<SongMeta, PeerAddress>> toLoad = new HashSet<SimpleEntry<SongMeta, PeerAddress>>();
	private Set<Song> loaded = new HashSet<Song>();
	private Set<String> processIdsMetaLoad = new HashSet<String>();
	private Set<String> processIdsSongLoad = new HashSet<String>();
	
	private Set<SongMeta> loadedSongMetas = new HashSet<SongMeta>();

	int fileCount = 0;

	// ***********
	// Constructor
	// ***********

	public DefaultFileLoader(FileStack fileStack, I_Filter filter, int maxSongs, I_P2P p2p) {
		this.fileStack = fileStack;
		this.filter = filter;
		this.maxSongs = maxSongs;
		this.p2p = p2p;
		
		logger.debug("Created. {}",this.toString());
	}

	// **************
	// Public methods
	// **************

	// **************
	// Public methods
	// **************

	public boolean equalConfig(FileStack fileStack, I_Filter filter) {

		if (!this.fileStack.equals(fileStack)) {
			return false;
		}

		if (!this.filter.equals(filter)) {
			return false;
		}

		return true;
	}

	public void execute() {

		logger.debug("Start");

		long startTime = System.currentTimeMillis();
		long currentTime = System.currentTimeMillis();

		loadSongMeta(this.maxSongs);
		
		int loadTries = 0;
		int maxLoadTries = 3;

		boolean stayAlive = true;
		while (stayAlive) {

			synchronized (this.loaded) {
				if (this.loaded.size() > 0) {
					for (Song s : this.loaded) {
						if (this.fileStack.addSong(s)) {
							this.fileCount++;
						}
					}
					this.loaded.clear();
				}
			}

			int number = (this.processIdsSongLoad.size() + this.fileCount + this.toLoad.size());
			if (number < this.maxSongs && loadTries <= maxLoadTries ) {
				if (this.processIdsMetaLoad.size() <= 0) {
					loadSongMeta(this.maxSongs - number);
				}
				loadTries++;
			}

			synchronized (this.toLoad) {
				if (this.toLoad.size() > 0) {
					loadSongs(this.toLoad);
					this.toLoad.clear();
				}
			}

			try {
				Thread.sleep(500);
			}
			catch (Exception e) {

			}

			currentTime = System.currentTimeMillis();
			stayAlive = (this.fileCount < this.maxSongs) && 
			!( (loadTries > maxLoadTries) && this.processIdsMetaLoad.size() <= 0 && this.processIdsSongLoad.size() <= 0 && this.toLoad.size() <= 0 && this.loaded.size() <= 0 ) &&
			(startTime - currentTime < DefaultFileLoader.MAX_WAIT_TIME);
		}

		logger.debug("{} : Stop. Got {} songs", this, this.fileCount);

	}

	// **************
	// Thread methods
	// **************

	@Override
	public void run() {
		execute();
	}

	// ********************
	// I_FileLoader methods
	// ********************

	public void deliverSongMetas(List<SimpleEntry<SongMeta, PeerAddress>> songMetas, List<String> finishedProcessIds) {
		logger.debug("songMetas: {} , finishedProcessIds: {}", Arrays.toString(songMetas.toArray()), Arrays.toString(finishedProcessIds.toArray()));
		for (SimpleEntry<SongMeta, PeerAddress> sm : songMetas) {
			if ( DefaultStorageAccess.getSingleton().getSongByMetaInfo(sm.getKey()) == null 
					&& this.filter.verify(sm.getKey())
						&& !this.loadedSongMetas.contains(sm.getKey()) ) {
				
				synchronized (this.toLoad) {
					this.toLoad.add(sm);
				}
				synchronized (this.loadedSongMetas) {
					this.loadedSongMetas.add(sm.getKey());
				}				
			}
		}
		synchronized (this.processIdsMetaLoad) {
			this.processIdsMetaLoad.removeAll(finishedProcessIds);
		}
	}

	public void deliverSongs(List<Song> songs, List<String> finishedProcessIds) {
		logger.debug("songs: {} , finishedProcessIds: {}", Arrays.toString(songs.toArray()), Arrays.toString(finishedProcessIds.toArray()));
		synchronized (this.processIdsSongLoad) {
			this.processIdsSongLoad.removeAll(finishedProcessIds);
		}
		synchronized (this.loaded) {
			for(Song s : songs){
				this.loaded.add(s);
				logger.info("Downloaded song : {}",s);
			}
		}
		logger.debug("{} songs loaded", songs.size());

	}
	
	public boolean livingMetaLoadProcesses() {
		refreshProcessList(this.processIdsMetaLoad);
		return (this.processIdsMetaLoad.size() > 0);
	}

	public boolean livingSongLoadProcesses() {
		refreshProcessList(this.processIdsSongLoad);
		return (this.processIdsSongLoad.size() > 0);
	}
	
	public String toString(){
		return this.getClass().getSimpleName() + "[" + this.fileStack.getKeyword() + "," + this.maxSongs + "]";
	}

	// ***************
	// Private methods
	// ***************

	private void loadSongMeta(int numberSongs) {
		logger.debug("numberSongs: {}", numberSongs);
		String processId = this.p2p.getSongMetas(this.fileStack.getKeyword(), numberSongs, this);
		synchronized (this.processIdsMetaLoad) {
			if (!this.processIdsMetaLoad.contains(processId)) {
				this.processIdsMetaLoad.add(processId);
			}
		}
	}

	private void loadSongs(Set<SimpleEntry<SongMeta, PeerAddress>> songMetas) {
		logger.debug("songMetas: {}", Arrays.toString(songMetas.toArray()));
		synchronized (this.processIdsSongLoad) {
			for (SimpleEntry<SongMeta, PeerAddress> sm : songMetas) {
				String processId = this.p2p.loadSong(sm.getKey(), sm.getValue(), this);
				this.processIdsSongLoad.add(processId);
			}
		}
	}

	private void refreshProcessList(Set<String> processList) {
		synchronized (processList) {
			HashSet<String> newList = new HashSet<String>();
			Iterator<String> it = processList.iterator();
			while (it.hasNext()) {
				String id = it.next();
				if (this.p2p.isProcessAlive(id)) {
					newList.add(id);
				}
			}

			processList.clear();
			processList.addAll(newList);
		}
	}

}
