package p2psaa.infrastructure.fileHandler;

public interface I_NewFileListener {

	public abstract void newLocalFile(Song song);
}
