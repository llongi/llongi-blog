package p2psaa.ui.gui;


public class Clock {
	
	private long startingTime ;
	
	


	public void start(){
		
		startingTime = System.currentTimeMillis();
		
	}
	
	
	public String getTimeString()  {

			long time2 = System.currentTimeMillis();
			
			long difference = time2 - startingTime;
			
			long seconds = (difference / 1000) % 60;
			
			long minutes = (difference / 1000)/60;
			
			
			if(seconds < 10){
				
				String time = "0" + minutes + ":0"+seconds ;
				return time;
			}else{
				String time = "0" + minutes + ":"+seconds ;
				return time;
			}
	}
	
	public void stopAndReset(){
		startingTime = 0;
	}
	

}
