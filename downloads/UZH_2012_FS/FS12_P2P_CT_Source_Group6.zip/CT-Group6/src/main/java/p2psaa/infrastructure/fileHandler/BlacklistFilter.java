package p2psaa.infrastructure.fileHandler;

import java.util.Arrays;
import java.util.List;

public class BlacklistFilter implements I_Filter {

	// **********
	// Attributes
	// **********

	private final List<String> blacklist;

	// ***********
	// Constructor
	// ***********

	public BlacklistFilter() {
		this.blacklist = null;
	}

	public BlacklistFilter(final List<String >blacklist) {
		this.blacklist = blacklist;
	}

	// **************
	// Public methods
	// **************

	/*
	 * (non-Javadoc)
	 * 
	 * @see p2psaa.infrastructure.fileHandler.I_Filter#verify(p2psaa.infrastructure.fileHandler.SongMeta)
	 */
	public boolean verify(final SongMeta songMeta) {
		
		for(String s : this.blacklist){
			if( songMeta.getTitle().equalsIgnoreCase(s) ){
				return false;
			}
		}
		
		return true;
	}

	@Override
	public String toString() {
		if (this.blacklist == null) {
			return this.getClass().getSimpleName() + "[Empty blacklist]";
		}
		else {
			return this.getClass().getSimpleName() + Arrays.toString(this.blacklist.toArray());
		}
	}

}
