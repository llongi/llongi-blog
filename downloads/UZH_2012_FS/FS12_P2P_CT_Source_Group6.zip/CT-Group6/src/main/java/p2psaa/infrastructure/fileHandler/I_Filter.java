package p2psaa.infrastructure.fileHandler;

public interface I_Filter {

	/**
	 * Returns true if the given song is ok
	 */
	public abstract boolean verify(SongMeta songMeta);

}
