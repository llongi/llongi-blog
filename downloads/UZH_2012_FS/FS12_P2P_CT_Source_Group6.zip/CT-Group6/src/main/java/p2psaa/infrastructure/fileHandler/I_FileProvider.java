package p2psaa.infrastructure.fileHandler;

public interface I_FileProvider {

	public abstract Song getSong(String keyword, I_Filter filter);

}
