package p2psaa.infrastructure.p2p;

import java.io.Serializable;

public class P2PRequest implements Serializable {

	private static final long serialVersionUID = -7966058911062710123L;

	public static enum RequestType {
		SONGMETA, SONG
	};

	private final RequestType requestType;
	private final Object requestPayload;

	public P2PRequest(RequestType requestType, Object requestPayload) {
		this.requestPayload = requestPayload;
		this.requestType = requestType;
	}

	public RequestType getRequestType() {
		return requestType;
	}

	public Object getRequestPayload() {
		return requestPayload;
	}
	
	public String toString(){
		return "P2PRequest[" + this.requestType + "," + requestPayload + "]";
	}

}
