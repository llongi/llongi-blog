package p2psaa.test.infrastructure.fileHandler;

public class TestDefaultStorageAccess {

	
}
