package p2psaa.junit.testdata;

import java.util.ArrayList;
import java.util.List;

import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.fileHandler.SongMeta;

public class Songs {

	/**
	 * Artist: "Iron Maiden" Genre: "Metal"
	 * 
	 */
	public static List<Song> getSongs(final int number, final String artist, final String genre) {

		ArrayList<Song> songs = new ArrayList<Song>();

		for (Integer i = 0; i < number; i++) {
			SongMeta meta = new SongMeta(artist, "Song " + i + " Title", genre);
			Song song = new Song("adummy.file", meta);
			songs.add(song);
		}

		return songs;
	}
}
