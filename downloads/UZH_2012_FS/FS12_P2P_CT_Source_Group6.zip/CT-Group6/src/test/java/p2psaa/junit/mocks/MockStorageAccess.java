package p2psaa.junit.mocks;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.fileHandler.I_Filter;
import p2psaa.infrastructure.fileHandler.I_NewFileListener;
import p2psaa.infrastructure.fileHandler.I_StorageAccess;
import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.fileHandler.SongMeta;

public class MockStorageAccess implements I_StorageAccess {
	Logger logger = LoggerFactory.getLogger("MockStorageAccess");

	private final List<Song> content = new ArrayList<Song>();
	private final String tempDir;

	public MockStorageAccess(final List<Song> content, final String tempDir) {
		this.logger.info("Created");
		this.content.addAll(content);
		this.tempDir = tempDir;
	}

	public Song getRandomSong(final String keyword, final I_Filter filter) {
		this.logger.info("{} , {}", keyword, filter);

		for (final Song s : this.content) {
			if (s.getSongMeta().getArtist().equalsIgnoreCase(keyword) || s.getSongMeta().getGenre().equalsIgnoreCase(keyword)
				|| s.getSongMeta().getTitle().equalsIgnoreCase(keyword)) {
				return s;
			}
		}

		return null;
	}

	public List<Song> getAllSongs() {
		return this.content;
	}

	public List<Song> getAllSongs(final String keyword, final I_Filter filter) {
		this.logger.info("{} , {}", keyword, filter);

		final List<Song> result = new ArrayList<Song>();

		for (final Song s : this.content) {
			if (s.getSongMeta().getArtist().equalsIgnoreCase(keyword) || s.getSongMeta().getGenre().equalsIgnoreCase(keyword)
				|| s.getSongMeta().getTitle().equalsIgnoreCase(keyword)) {
				result.add(s);
			}
		}

		return result;
	}

	public void addSong(final Song song) {
		this.content.add(song);
	}

	public Song getSongByMetaInfo(final SongMeta metaInfo) {
		for (final Song s : this.content) {
			if (s.getSongMeta().equals(metaInfo)) {
				return s;
			}
		}

		return null;
	}

	public void addLikeInformation(final Song song, final List<String> keywords) {

	}

	public void addDontLikeInformation(final Song song, final List<String> likeKeywords) {

	}

	public List<String> getKeywordsLike(final String likeKeyword, final String globalKeyword) {

		return null;
	}

	public Song addSongFromP2P(SongMeta metaInfo, byte[] content) {

		String fileName = metaInfo.getArtist() + metaInfo.getTitle() + ".mp3";
		fileName = fileName.replaceAll(" ", "_");
		File f = new File(this.tempDir + File.separator + fileName);
		FileOutputStream fo = null;
		try {
			f.createNewFile();
			fo = new FileOutputStream(f);
			fo.write(content);
			fo.flush();
		}
		catch (IOException e) {

		}
		finally {
			if (fo != null) {
				try {
					fo.close();
				}
				catch (IOException e) {
				}
			}
		}

		Song song = new Song(f.getAbsolutePath(), metaInfo);

		return song;
	}

	public Song addSongFromFile(String filePath) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getRandomKeywordLike(String likeKeyword, String globalKeyword) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> getAllKeywordsLike(String likeKeyword, String globalKeyword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addLikeInformation(String keyword, List<String> likeKeywords) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addDontLikeInformation(String keyword,
			List<String> dontLikeKeywords) {
		// TODO Auto-generated method stub
		
	}
 
	@Override
	public void registerNewLocalFileListener(I_NewFileListener listener) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<String> getAllKeywordsDontLike(String dontLikeKeyword,
			String globalKeyword) {
		// TODO Auto-generated method stub
		return null;
	}

}
