package p2psaa.junit.mocks;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.fileHandler.DefaultStorageAccess;
import p2psaa.settings.Configuration;

public class WrappedStorageAccess extends DefaultStorageAccess {

	Logger logger = LoggerFactory.getLogger("WrappedStorageAccess");
	
	private String name;
	
	public WrappedStorageAccess(
			String pathDontLikeKeywordsMap,
			String pathLikeKeywordsMap, 
			String pathSongsSet,
			String p2pAppPathData,
			String p2pAppPathDownload,
			String p2pAppPathMain){
		
		
		this.pathDontLikeKeywordsMap = pathDontLikeKeywordsMap;
		this.pathLikeKeywordsMap = pathLikeKeywordsMap;
		this.pathSongsSet = pathSongsSet;
		this.p2pAppPathData = p2pAppPathData;
		this.p2pAppPathDownload = p2pAppPathDownload;
		this.p2pAppPathMain = p2pAppPathMain;
		
		initDirs();

		initMaps();
		
		logger.info("Created.  {}", this.toString());
		
	}
	
	
}
