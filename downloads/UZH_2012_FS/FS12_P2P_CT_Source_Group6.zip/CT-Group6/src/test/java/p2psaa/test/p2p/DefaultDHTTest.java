package p2psaa.test.p2p;

import java.io.*;
import java.net.InetAddress;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.tomp2p.peers.PeerAddress;

import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.fileHandler.SongMeta;
import p2psaa.infrastructure.p2p.I_P2PAccess;
import p2psaa.infrastructure.p2p.DefaultP2PAccess;
import p2psaa.junit.mocks.MockStorageAccess;
import p2psaa.junit.mocks.WrappedStorageAccess;

public class DefaultDHTTest {

	private static Logger logger = LoggerFactory.getLogger("DefaultDHTTest");

	@Test
	public void testGetPeers() {

		try {

			logger.info("Start");

			logger.info("Create DHTs for peers");

			MockStorageAccess storageAccess = new MockStorageAccess(new ArrayList<Song>(), "");

			Integer portPeerA = 5000;
			Integer portPeerB = 5001;
			Integer portPeerC = 5002;

			I_P2PAccess dhtPeerA = new DefaultP2PAccess(portPeerA, storageAccess);
			I_P2PAccess dhtPeerB = new DefaultP2PAccess(portPeerB, storageAccess);
			I_P2PAccess dhtPeerC = new DefaultP2PAccess(portPeerC, storageAccess);

			logger.info("Start first peer");

			// No other peer available yet
			dhtPeerA.startWithoutBootstrap();

			logger.info("Start other peers and connect them to first peer");

			dhtPeerB.bootstrap(InetAddress.getLocalHost(), portPeerA);
			dhtPeerC.bootstrap(InetAddress.getLocalHost(), portPeerA);

			logger.info("All peers should know each other now");

			// ******************
			// Add content to DHT
			// ******************

			dhtPeerB.put("Rock");
			dhtPeerA.put("Rock");
			dhtPeerC.put("Metal");

			// *************************
			// Request Peers with Keyword from DHT
			// **************************

			// Request 1

			logger.info("Peer C tries to find peers with 'Rock' songs");

			List<PeerAddress> results = dhtPeerC.getPeers("Rock");

			logger.info("Got {} peers with 'Rock' songs. Expected 2 peers", results.size());
			for (PeerAddress pa : results) {
				logger.info(pa.toString());
			}
			Assert.assertTrue(results.size() == 2);

			// Request 2

			logger.info("Peer A tries to find peers with 'Metal' songs.");

			results = dhtPeerA.getPeers("Metal");

			logger.info("Got {} peers with 'Metal' songs. Expected 1 peer", results.size());
			for (PeerAddress pa : results) {
				logger.info(pa.toString());
			}
			Assert.assertTrue(results.size() == 1);

			// Add more keywords

			logger.info("Add some more data to dht");

			dhtPeerA.put("Iron Maiden");
			dhtPeerC.put("Iron Maiden");

			// Request 3

			logger.info("Peer B tries to find peers with 'Iron Maiden' songs");

			results = dhtPeerB.getPeers("Iron Maiden");

			logger.info("Got {} peers with 'Metal' songs. Expected 2 peer", results.size());
			for (PeerAddress pa : results) {
				logger.info(pa.toString());
			}
			Assert.assertTrue(results.size() == 2);

			// *****
			// Clean
			// *****

			dhtPeerA.disconnect();
			dhtPeerB.disconnect();
			dhtPeerC.disconnect();

		}
		catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	@Test
	public void testGetSongMetas() {

		try {

			logger.info("Start");

			logger.info("Create DHTs for peers");

			String tempDir = "C:\\Users\\robert.DOMAIN\\workspace_uzh\\p2pradio\\src\\test\\resources\\temp";

			List<Song> content = new ArrayList<Song>();

			SongMeta songMeta = new SongMeta("Simon & Garfunkel", "Sound Of Silence", "Rock");
			Song song = new Song("C:\\Users\\robert.DOMAIN\\workspace_uzh\\p2pradio\\src\\test\\resources\\testSong.mp3", songMeta);
			content.add(song);

			songMeta = new SongMeta("Timon & Pumba", "Hakuna Matata", "Rock");
			song = new Song("C:\\Users\\robert.DOMAIN\\workspace_uzh\\p2pradio\\src\\test\\resources\\testSong2.mp3", songMeta);
			content.add(song);

			MockStorageAccess storageAccess = new MockStorageAccess(content, tempDir);

			Integer portPeerA = 5000;
			Integer portPeerB = 5001;
			Integer portPeerC = 5002;

			I_P2PAccess dhtPeerA = new DefaultP2PAccess(portPeerA, storageAccess);
			I_P2PAccess dhtPeerB = new DefaultP2PAccess(portPeerB, storageAccess);
			I_P2PAccess dhtPeerC = new DefaultP2PAccess(portPeerC, storageAccess);

			logger.info("Start first peer");

			// No other peer available yet
			dhtPeerA.startWithoutBootstrap();

			logger.info("Start other peers and connect them to first peer");

			dhtPeerB.bootstrap(InetAddress.getLocalHost(), portPeerA);
			dhtPeerC.bootstrap(InetAddress.getLocalHost(), portPeerA);

			logger.info("All peers should know each other now");

			// ******************
			// Add content to DHT
			// ******************

			dhtPeerB.put("Rock");

			// ********************
			// Try to get Peers
			// ********************

			List<PeerAddress> peers = dhtPeerA.getPeers("Rock");

			logger.info("Got {} peers with 'Rock' songs. Expected 1 peer", peers.size());
			for (PeerAddress pa : peers) {
				logger.info(pa.toString());
			}
			Assert.assertTrue(peers.size() == 1);

			// ********************
			// Try to get PeerMetas
			// ********************

			List<SongMeta> songMetas = dhtPeerA.loadAllSongMeta(peers.get(0), "Rock", 5);

			logger.info("Got {} SongMetas for keyword 'Rock'. Expected 2", songMetas.size());
			for (SongMeta sm : songMetas) {
				logger.info(sm.toString());
			}
			Assert.assertTrue(songMetas.size() == 2);

			// ***************
			// Try to get Song
			// ***************

			List<Song> resultSongs = new ArrayList<Song>();

			resultSongs.add(dhtPeerA.loadSong(peers.get(0), songMetas.get(0)));
			resultSongs.add(dhtPeerA.loadSong(peers.get(0), songMetas.get(1)));

			for (Song s : resultSongs) {
				logger.info("Got song {}", s);
			}

			Assert.assertTrue(resultSongs.size() == 2);

			// *****
			// Clean
			// *****

			for (Song s : resultSongs) {
				File f = new File(s.getFileName());
				if (f.exists()) {
					f.delete();
				}
			}

		}
		catch (Exception e) {

		}

	}
}
