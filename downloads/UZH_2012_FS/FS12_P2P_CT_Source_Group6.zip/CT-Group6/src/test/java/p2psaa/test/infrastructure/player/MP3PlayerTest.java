package p2psaa.test.infrastructure.player;

import org.junit.Test;

import p2psaa.application.player.MP3Player;
import p2psaa.infrastructure.fileHandler.Song;

public class MP3PlayerTest {

	@Test
	public static void main(final String[] args) {

		Song mySong = new Song("src/test/resources/testSong.mp3", null);

		MP3Player.play(mySong);

		// play for 20 seconds, and print seconds played
		for (int i = 0; i < 20; i++) {
			try {
				Thread.sleep(1000);
			}
			catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			int time = MP3Player.getSecondsPlayed();

			System.out.println(time);

		}

		MP3Player.stop();
	}

}
