package p2psaa.junit.mocks;

import java.util.AbstractMap;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.List;

import net.tomp2p.peers.PeerAddress;

import p2psaa.infrastructure.fileHandler.I_FileLoader;
import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.fileHandler.SongMeta;

public class MockFileLoader implements I_FileLoader {

	public List<SimpleEntry<SongMeta, PeerAddress>> songMetas = new ArrayList<AbstractMap.SimpleEntry<SongMeta, PeerAddress>>();
	public List<Song> songs = new ArrayList<Song>();

	public void deliverSongMetas(List<SimpleEntry<SongMeta, PeerAddress>> songMetas, List<String> processId) {

		this.songMetas.addAll(songMetas);

	}

	public void deliverSongs(List<Song> songs, List<String> processIds) {
		this.songs.addAll(songs);
	}

}
