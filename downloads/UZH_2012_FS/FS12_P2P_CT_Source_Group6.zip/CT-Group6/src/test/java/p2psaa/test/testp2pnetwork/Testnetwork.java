package p2psaa.test.testp2pnetwork;

import java.io.File;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import p2psaa.infrastructure.fileHandler.DefaultStorageAccess;
import p2psaa.infrastructure.p2p.DefaultP2PAccess;
import p2psaa.infrastructure.p2p.I_P2PAccess;
import p2psaa.junit.mocks.WrappedStorageAccess;

public class Testnetwork {

	private static Logger logger = LoggerFactory.getLogger("Testnetwork");
	
	private List<I_P2PAccess> peers = new ArrayList<I_P2PAccess>();
	private Integer currentPort = 6000;
	private Integer startPort = currentPort;
	private String localAddress = "";
	
	public Testnetwork(String[] paths, String localAddress){
		this.localAddress = localAddress;
		for(String p : paths){
			peers.add(createPeer(p));
		}
	}	
	
	private void removeDir(File start){
		if( start.isDirectory() ){
			for(File f : start.listFiles()){
				removeDir(f);
			}
			start.delete();
		} else {
			start.delete();
		}
	}
	
	
	private I_P2PAccess createPeer(String contentPath){
		
		String base = contentPath + "p2p/";
		
		if( (new File(base)).exists() ){
			removeDir(new File(base));
		}
		
		String p2pAppPathMain = base;
		String p2pAppPathData = p2pAppPathMain + "data/";
		
		String pathDontLikeKeywordsMap = p2pAppPathData + "a.save"; 
		String pathLikeKeywordsMap = p2pAppPathData + "b.save";
		String pathSongsSet = p2pAppPathData + "c.save";
		
		String p2pAppPathDownload = p2pAppPathMain + "dl/"; 
				
		WrappedStorageAccess ws 
			= new WrappedStorageAccess(
					pathDontLikeKeywordsMap, 
					pathLikeKeywordsMap,
					pathSongsSet,
					p2pAppPathData, 
					p2pAppPathDownload,  
					p2pAppPathMain);
		
		DefaultP2PAccess dp2p = new DefaultP2PAccess(currentPort, ws);
		
		try {
			if( currentPort ==  startPort ){
				dp2p.startWithoutBootstrap();
			} else {
				dp2p.bootstrap(InetAddress.getByName(localAddress), startPort);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
		File dir = new File(contentPath);
		if( dir.isDirectory() ){
			String[] content = dir.list();
			for(String c : content){
				if( c.endsWith(".mp3") || c.endsWith(".MP3") ){
					String filePath = contentPath + c;
					ws.addSongFromFile(filePath);
				}				
			}
		}		
		
		currentPort++;
		
		return dp2p;
				
	}
	
	public static void main(String[] args){
		
		
		/*
		 * - Given directory will be scanned for all mp3 files 
		 * - For every directory 1 peer + 1 storageaccess is created
		 * - storageaccess will used the corresponding directory as work directory
		 * - every peer will announce all mp3 files in his directory
		 * - peers will connect to each other
		 */
		
		String[] peerPaths 
			= new String[] {
				 "C:\\Users\\robert.DOMAIN\\Desktop\\P2PData\\IronMaidenPeer\\" ,
				 "C:\\Users\\robert.DOMAIN\\Desktop\\P2PData\\OpethPeer\\" ,
				 "C:\\Users\\robert.DOMAIN\\Desktop\\P2PData\\HypocrisyPeer\\" 
			};
			
		Testnetwork tn = new Testnetwork(peerPaths,"89.206.99.221");
		
		
	}
	
	
}
