package p2psaa.junit.mocks;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import net.tomp2p.peers.PeerAddress;

import p2psaa.infrastructure.fileHandler.Song;
import p2psaa.infrastructure.fileHandler.SongMeta;
import p2psaa.infrastructure.p2p.I_P2PAccess;

public class MockDHT implements I_P2PAccess {

	private final HashMap<String, List<PeerAddress>> content = new HashMap<String, List<PeerAddress>>();

	public MockDHT(HashMap<String, List<PeerAddress>> content) {

		this.content.putAll(content);
	}

	public void put(String key, PeerAddress value) {

		List<PeerAddress> l = this.content.get(key);
		if (l == null) {
			l = new ArrayList<PeerAddress>();
			this.content.put(key, l);
		}
		l.add(value);
	}

	public void put(String key) {
		// Not implemented
	}

	public void bootstrap(InetAddress ipTarget, Integer portTarget) throws Exception {
		// Not implemented
	}

	public void disconnect() throws Exception {
		// Not implemented
	}

	public void startWithoutBootstrap() throws Exception {
		// TODO Auto-generated method stub

	}

	public List<PeerAddress> getPeers(String key) {

		List<PeerAddress> l = this.content.get(key);
		if (l == null) {
			return new ArrayList<PeerAddress>();
		}
		return l;

	}

	public List<SongMeta> loadAllSongMeta(PeerAddress peerAddress, String keyword, Integer maxNbr) {
		// TODO Auto-generated method stub
		return null;
	}

	public Song loadSong(PeerAddress peerAddress, SongMeta songMeta) {
		// TODO Auto-generated method stub
		return null;
	}

}
